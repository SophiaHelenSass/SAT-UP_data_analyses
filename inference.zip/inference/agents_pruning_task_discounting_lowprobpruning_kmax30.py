"""
Authors: Lorenz Goenner 
"""

#import
import torch
from torch.distributions import Categorical, Bernoulli
from numpy import nan

zeros = torch.zeros
ones = torch.ones


import numpy as np


class BackInductionSAT_UP_Discounting_LowprobPruning_kmax30(object):
    def __init__(self,
                 planet_confs, # Matrix of zeros and ones
                 runs=1, # number of parallel runs (i.e. agents). For each run, one can specify a different set of model parameters.
                 mini_blocks=1,
                 trials=1,
                 na=2, # number of actions
                 ns=6, # number of states
                 costs=None,
                 utility=None, # Utility of planet types. Can be set to rewards of the planets
                 planning_depth=1,
                 depths=None,
                 variable_depth=False):
        
        self.runs = runs
        self.nmb = mini_blocks
        self.trials = trials
        self.np = 3  # number of free model parameters

        self.depth = planning_depth  # maximal planning depth
        if depths is None:
            self.depths = [torch.tensor([planning_depth - 1]).repeat(self.runs)]
        if variable_depth:
            self.make_depth_transitions(rho=.8)
        else:
            self.make_depth_transitions()
        self.na = na  # number of actions
        self.ns = ns  # number of states

        # matrix containing planet type in each state
        self.pc = planet_confs
        
        if costs is not None:
            self.costs = costs
        else:
            self.costs = torch.tensor([-.2, -.5])

        if utility is not None:
            self.utility = utility
        else:
            self.utility = torch.arange(-2., 3., 1.)

        self.transitions = torch.tensor([2, 3, 4, 5, 0, 1]) 
  
    def set_parameters(self, trans_par=None, true_params=False):

        if trans_par is not None:
            if true_params:
                self.beta = (trans_par[..., 0]) # Response noise
                self.theta = trans_par[..., 1] # Bias term in sigmoid function fot action-selection             
                self.k = (trans_par[..., 3]) # assume k in [0,30] 
            else:
                assert trans_par.shape[-1] == self.np
                self.beta = (trans_par[..., 0]).exp() # Response noise
                self.theta = trans_par[..., 1] # Bias term in sigmoid function fot action-selection
                self.k = 30*(trans_par[..., 2]).sigmoid() # k in [0,30] 
        else:
            self.beta = torch.tensor([10.]).repeat(self.runs)
            self.theta = zeros(self.runs)       
            self.k = zeros(self.runs)   
            
        self.batch_shape = self.beta.shape


        self.tp_mean0 = torch.tensor([1., 1.]).expand(self.batch_shape + (2,))     
        self.tp_mean1 = torch.tensor([.5, .5]).repeat(self.batch_shape + (1,))
        self.tau = torch.tensor(1e10).expand(self.batch_shape)

        # (Estimated) probability of high-probability transition
        self.tp_mean = [self.tp_mean0]

        # state transition matrices
        self.tm = []

        # expected state value
        self.Vs = []

        # action value difference: Q(a=jump (two steps)) - Q(a=move (one step))
        self.D = []

        # response probability
        self.logits = []

    def make_depth_transitions(self, rho=1.):

        tm = torch.eye(self.depth).repeat(self.runs, 1, 1)
        if self.depth > 1:
            tm = rho*tm + (1-rho)*(ones(self.depth, self.depth) - tm)/(self.depth-1)

        self.tm_depths = tm

    def make_transition_matrix(self, p, uncertain_planet):
        na = self.na  # number of actions (2)
        ns = self.ns  # number of states (6)
        shape = self.batch_shape  # number of runs

        # create the regular transition matric (move = 1 step, jump = 2 steps, p = 1.0)
        tm = zeros(shape + (na, ns, ns))
        
       # move left action to planets without uncertainty
        tm[..., 0, :-1, 1:] = torch.eye(ns-1) 
        tm[..., 0, -1, 0] = 1

        # jump action to planets without uncertainty
        tm[..., 1, :-2, 2:] = torch.eye(ns-2)
        tm[..., 1, -2, 0] = torch.tensor(1.0)
        tm[..., 1, -1, 1] = torch.tensor(1.0)        

        j = uncertain_planet
        tm1 = torch.tensor(np.copy(tm)) # Create new reference
        
       # one step left action to planet with uncertainty       
        tm1[..., 0, np.mod(j-1,6), j] = torch.tensor(0.5)
        tm1[..., 0, np.mod(j-1,6), np.mod(j-1,6)] = torch.tensor(0.25)
        tm1[..., 0, np.mod(j-1,6), np.mod(j+1,6)] = torch.tensor(0.25)        

        # two step action to planet with uncertainty        
        tm1[..., 1, np.mod(j-2,6), j] = torch.tensor(0.5)
        tm1[..., 1, np.mod(j-2,6), np.mod(j-1,6)] = torch.tensor(0.25)
        tm1[..., 1, np.mod(j-2,6), np.mod(j+1,6)] = torch.tensor(0.25)        

        self.tm.append(tm1)

       

    def compute_state_values(self, block):
       
        
        # self.noise : placeholder for position of the uncertain planet
        
        self.make_transition_matrix(self.noise, self.uncertain_planet_pos) # This appends to self.tm.

        tm = self.tm[-1]  #transition probabilities for one or two step action to uncertain planet are added, shape : (batch_shape, na, ns, ns)
        depth = self.depth  # planning depth
        shape = self.batch_shape #number of parallel simulations???

        utility = self.utility # planet values (devided by 10)
        
        prob = self.tp_mean1[:, self.noise[0]]
        odds_against_success = (1 - prob)/prob
        
        if len(odds_against_success.shape) == 2:
            gamma = 1.0 / (1 + torch.einsum('...i, ...ij ->...ij', odds_against_success[:,self.noise[0]], self.k))
        elif len(odds_against_success.shape) == 1:
                    
            gamma = 1.0 / (1 + torch.einsum('...i, ...i ->...i', odds_against_success[:], self.k))            

        '''
            self.pc : Planet configs, shape [1, num_trials, num_states, num_values]
        '''
        
        Vs = [torch.sum(utility * self.pc[:, block, ...], -1).expand(shape+(self.ns,))] 
        '''
            Vs : planet values for the current mini-block (block) devided by 10, so it is element of [-2, -1, 0, 1, 2],
            shape : n_samples, n_subjects, n_states = 6
        '''
        # action value difference: Q(a=jump) - Q(a=move)
        D = []
        
        '''weighted sum of transition maztrix and planet values in current mini-block + action costs (which are zero),
        i.e. for each state and action the probabilities (from tm) are weighted with the state values (from Vs[-1]) and summed up
        --> expected value for each combination of state and action = Q-Value
        
        '''
      

        R = torch.einsum('...ijkl,...il->...ikj', tm, Vs[-1]) + self.costs # shape : (batch_shape, ns, na)               

        Q = R
        for d in range(1, depth+1):
            # compute Q value differences for different actions

            # Approach for discounting:
            # Discount the value of those actions which lead to the uncertain planet!
            
            ''' Q-value for move action to uncertain planet is multiplied with gamma : 
                shape[n_agents, n_subects(?), n_states, _actions]
                for each state reached by action move or jump there is one state value which equals the planet value if it is a certain planet
                if it is an uncertain planet, the state value is multiplied with gamma (which is fed into the function from the inference)
                example: uncertain planet Q-value before discounting = -1.5; Q-value after discounting : -1.5 * 0.112(gamma) = -0.1687
            '''
             
            Q[..., np.mod(self.uncertain_planet_pos[0] - 1, 6), 0] *= gamma
         
            '''
            Q-value for jump action to uncertain planet is multiplied with gamma (procedure and result is the same as for move)
            '''
            
            Q[..., np.mod(self.uncertain_planet_pos[0] - 2, 6), 1] *= gamma
            ''' each Q-value of jump is subtrachted from its corresponding Q-value of move from the given state
            e.g. move from planet 1: Q = -2; jump from planet 1 = 1, dQ= Qjump - Qmove = 3'''
            dQ = Q[..., 1] - Q[..., 0]

            ''' compute response probability: 
                p = 0.5 --> no difference between Q-Values
                p = 1.0 --> jump is clearly better
                p = 0 --> move is clearly better 
            '''
            p = (dQ * self.tau[..., None]).sigmoid()

            '''
            set new state values :
             based on probabilities p (preference for jump action) and p-1 (preference for move action)
             Q-values for jump and move are weighted with their respective choice probability (p for jump and 1-p for move)
            '''
            Vs.append(p * Q[..., 1] + (1-p) * Q[..., 0])

            D.append(dQ) #dQ values are saved here 
            
            '''
            Q-values are updated for the next planning depth iteration based on new state values Vs[-1]
            '''
            if d < depth:
                Q = torch.einsum('...ijkl,...il->...ikj', tm, Vs[-1]) + R

        '''
        makes a list with tensors which is updated for each planning depth 
        iteration with Vs for differnt planning depths
        you can access Vs for different planning depths with print(self.Vs[0])
        '''
        self.Vs.append(torch.stack(Vs)) 
        
        '''
        makes a list with tensors which is updated for each planning depth 
        iteration with Ds (delta Q) for differnt planning depths 
        '''
        self.D.append(torch.stack(D, -1))


    
    def update_beliefs(self, block, trial, states, conditions, responses=None):
        self.noise = conditions[0] 
        self.max_trials = conditions[1]
        self.uncertain_planet_pos = conditions[2]

        subs = torch.arange(self.runs)

        if trial == 0:
            self.make_transition_matrix(self.tp_mean[-1][..., subs, self.noise], self.uncertain_planet_pos)

        else:
            probs_new = self.tp_mean[-1][..., subs, self.noise]            

            tp_mean = self.tp_mean[-1].clone()

            tp_mean[..., subs, self.noise] = probs_new

            self.tp_mean.append(tp_mean)

            self.make_transition_matrix(probs_new, self.uncertain_planet_pos)

        # set beliefs about state (i.e. location of agent) to observed states
        self.states = states

    def plan_actions(self, block, trial):

        self.compute_state_values(block)

        D = self.D[-1][..., range(self.runs), self.states, :]

        beta = self.beta[..., None]
        theta = self.theta[..., None]
        self.logits.append(D * beta + theta)
        
    def sample_responses(self, block, trial):
        if trial == 0 and block > 0:
            probs = self.tm_depths[range(self.runs), self.depths[0]]
            depths = Categorical(probs=probs).sample()
            loc = depths > self.max_trials - 1
            depths[loc] = self.max_trials[loc] - 1
            self.depths.append(depths)
        else:
            depths = self.depths[-1]

        d = self.max_trials - trial - 1
        loc = d > depths
        d[loc] = depths[loc]
        
        logits = self.logits[-1]
        
    
        bern = Bernoulli(logits=logits[range(self.runs), d])

        res = bern.sample()
        valid = d > -1
        res[~valid] = nan

        return res
