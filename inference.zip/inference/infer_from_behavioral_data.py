"""
Authors: Lorenz Goenner & Sophia-Helen Sass
"""

import os
import numpy as np
import pylab as plt
import json
import pandas as pd
import torch
import pyro
import sys
import scipy.io as io
import scipy.stats as st
import seaborn as sns

sns.set(context = 'talk', style = 'white')
sns.set_palette("colorblind", n_colors=5, color_codes=True)

sys.path.append('../')
from tasks_pruning import SpaceAdventurePruning
from agents_pruning_task_rational_noalpha import BackInductionSAT_UP_Rational_noalpha
from agents_pruning_task_lowprobpruning import BackInductionSAT_UP_LowprobPruning
from agents_pruning_task_discounting_lowprobpruning_kmax30 import BackInductionSAT_UP_Discounting_LowprobPruning_kmax30
from simulate import Simulator
from inference import Inferrer
from helper_files import load_and_format_behavioural_data_SAT_UP_pilot1, load_and_format_behavioural_data_SAT_UP_pilot2, get_posterior_stats, errorplot 
from calc_BIC import calc_BIC_SAT_UP_logfiles


def format_posterior_samples(infer, labels, num_samples):
    pars_df, mg_df, sg_df = infer.sample_from_posterior(labels, n_samples=num_samples)
    # transform sampled parameter values to the true parameter range
    pars_df[r'$\beta$'] = torch.from_numpy(pars_df[r'$\tilde{\beta}$'].values).exp().numpy()
    pars_df.drop([r'$\tilde{\beta}$'], axis=1, inplace=True) 
    return pars_df.melt(id_vars=['subject'], var_name='parameter')
   
                        
def format_posterior_samples_lowprob_pruning(infer, labels, num_samples):
    pars_df, mg_df, sg_df = infer.sample_from_posterior(labels, n_samples=num_samples)
    pars_df[r'$\beta$'] = torch.from_numpy(pars_df[r'$\tilde{\beta}$'].values).exp().numpy()
    pars_df.drop([r'$\tilde{\beta}$'], axis=1, inplace=True) 
    return pars_df.melt(id_vars=['subject'], var_name='parameter')    


def format_posterior_samples_lowprob_pruning_discounting(infer, labels, num_samples):
    pars_df, mg_df, sg_df = infer.sample_from_posterior(labels, n_samples=num_samples)
    pars_df[r'$\beta$'] = torch.from_numpy(pars_df[r'$\tilde{\beta}$'].values).exp().numpy()
    pars_df[r'$k$'] = 30*torch.from_numpy(pars_df[r'$k$'].values).sigmoid().numpy()      
    pars_df.drop([r'$\tilde{\beta}$'], axis=1, inplace=True)
    return pars_df.melt(id_vars=['subject'], var_name='parameter')


# read config file
config_path = ''
config_file_bothcond = 'config_file_main.csv'
config_bothcond = pd.read_csv(config_path + config_file_bothcond)

runs0 = 1 # number of simulations / subjects
n_miniblocks_new = 144
trials0_new = np.int0(3*np.ones(n_miniblocks_new))

noise0_new_uncertainplanet = config_bothcond.uncertain_planet
noise0_new_uncertainplanet = np.asarray(noise0_new_uncertainplanet - 1) # Conversion from matlab to python indexing

conditions0_new = torch.zeros(3, runs0, n_miniblocks_new, dtype=torch.long)
conditions0_new[0] = torch.tensor(np.zeros(144), dtype=torch.long)[None, :] 
conditions0_new[1] = torch.tensor(trials0_new, dtype=torch.long)
conditions0_new[2] = torch.tensor(noise0_new_uncertainplanet, dtype=torch.long)[None, :]


planets_new_points = np.nan * np.ones([n_miniblocks_new, 6])
planets_new_index = [] 

for i in range(n_miniblocks_new):
    planets_new_points[i] = [config_bothcond.planet1[i], config_bothcond.planet2[i], config_bothcond.planet3[i], \
                             config_bothcond.planet4[i], config_bothcond.planet5[i], config_bothcond.planet6[i]]
    
# mapping needed from [-20, -10, 0, 10, 20] to [0,1,2,3,4]:
planets_new_index = np.int0( (planets_new_points + 20) / 10 )

vect0_new = np.eye(5)[planets_new_index]
ol0_new = torch.from_numpy(vect0_new)
confs0_new = ol0_new.repeat(runs0,1,1,1).float()

starts0_new = config_bothcond.start_pos
starts0_new = np.asarray(starts0_new)
starts0_new = starts0_new -1  # Conversion from Matlab to Python indexing
starts0_new = torch.from_numpy(starts0_new)

# Specify path for log files
logfile_path = ''

sim_number0 = 2

agent2_rational = {}
agent2_pruning = {}

fitting_agents = {}
elbo = {}
modelfit = {}
modelfit_per_miniblock = {}

pars_df = {}

# List of agent models to be inferred:
fitting_agent_keys = ['rational', 'lowprob_pruning', 'discounting_lowprob_pruning']

# Label for dataset:
subject_keys = ['pilot3']


n_iter = 500
n_particles = 100
n_samples = 1000
datapath = ''
datapath = logfile_path
datapath_out = ''

filenames = ["SAT_pruning.json"]
stimuli_testlogs, mask_testlogs, responses_testlogs, conditions_testlogs, ids_testlogs, scores_testlogs = load_and_format_behavioural_data_SAT_UP_pilot2(logfile_path, filenames)


for fitting_agent_key in fitting_agent_keys:
    
    fitting_agents['fit-' + fitting_agent_key] = {}
    elbo['fit-' + fitting_agent_key] = {}        
    modelfit['fit-' + fitting_agent_key] = {}       
    modelfit_per_miniblock['fit-' + fitting_agent_key] = {}

    pars_df['fit-' + fitting_agent_key] = {}            
    
    for subject_key in subject_keys:  
        print()    
        print('fitted: '+fitting_agent_key + ', simulated: '+subject_key)     
    
        fitting_agents['fit-'+fitting_agent_key][ 'sim-'+subject_key ] = {}
        modelfit['fit-'+fitting_agent_key][ 'sim-'+subject_key ] = {}    
        modelfit_per_miniblock['fit-'+fitting_agent_key][ 'sim-'+subject_key ] = {}
    


        if fitting_agent_key == 'rational':
            fitting_agents['fit-rational']['sim-' + subject_key] = BackInductionSAT_UP_Rational_noalpha(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=3)
                           
        
        elif fitting_agent_key == 'lowprob_pruning':        
            fitting_agents['fit-lowprob_pruning']['sim-' + subject_key]= BackInductionSAT_UP_LowprobPruning(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=3)                    

        
        elif fitting_agent_key == 'discounting_lowprob_pruning':        
            fitting_agents['fit-discounting_lowprob_pruning']['sim-' + subject_key]= BackInductionSAT_UP_Discounting_LowprobPruning_kmax30(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=3)   
            
        
        if fitting_agent_key == 'rational':
            infer = Inferrer(fitting_agents['fit-rational']['sim-' + subject_key], stimuli_testlogs, responses_testlogs, mask_testlogs)
            infer.fit(num_iterations=n_iter, num_particles=n_particles, optim_kwargs={'lr': 0.02})  # change the number of iterations here if you like
            labels_rational = [r'$\tilde{\beta}$', r'$\theta$']        
            labels = labels_rational
            pars_df_formatted = format_posterior_samples(infer, labels_rational, n_samples)

        elif fitting_agent_key == 'lowprob_pruning':
            infer = Inferrer(fitting_agents['fit-lowprob_pruning']['sim-' + subject_key], stimuli_testlogs, responses_testlogs, mask_testlogs)
            infer.fit(num_iterations=n_iter, num_particles=100, optim_kwargs={'lr': 0.02})
            labels = [r'$\tilde{\beta}$', r'$\theta$'] 
            pars_df_formatted = format_posterior_samples_lowprob_pruning(infer, labels, n_samples)
        
        
        elif fitting_agent_key == 'discounting_lowprob_pruning':    
            infer = Inferrer(
                fitting_agents['fit-discounting_lowprob_pruning']['sim-' + subject_key], 
                stimuli_testlogs, 
                responses_testlogs, 
                mask_testlogs
            )
            infer.fit(num_iterations=n_iter, num_particles=100, optim_kwargs={'lr': 0.02})
            labels = [r'$\tilde{\beta}$', r'$\theta$', r'$k$']
            pars_df_formatted = format_posterior_samples_lowprob_pruning_discounting(infer, labels, n_samples)

            
        elbo['fit-'+fitting_agent_key][ 'sim-' + subject_key ] = infer.loss[:]
        post_marg = infer.sample_posterior_marginal(n_samples=n_samples)        
        post_depth, m_prob, exc_count = get_posterior_stats(post_marg, mini_blocks = 144)
        np.savez(datapath_out + '/plandepth_stats_fit-' + fitting_agent_key+'_sim-'+subject_key+'_'+str(runs0)+'runs_'+str(n_iter)+'iter', post_depth, m_prob, exc_count)
        post_meanPD_firstAction = np.matmul(m_prob[0], np.arange(1,4))
        df_meanPD = pd.DataFrame(post_meanPD_firstAction) 
        pd.DataFrame(df_meanPD).to_csv(datapath_out + '/meanPD_1st_action_' + fitting_agent_key+'_'+subject_key+'_'+str(runs0)+'runs_'+str(n_iter)+'iter.csv')
       

        pars_df['fit-' + fitting_agent_key]['sim-' + subject_key], mg_df, sg_df = infer.sample_from_posterior(labels, n_samples=n_samples) 
      
        pars_df['fit-' + fitting_agent_key]['sim-' + subject_key]['IDs'] = np.array(ids_testlogs)[pars_df['fit-' + fitting_agent_key]['sim-' + subject_key].subject.values - 1]
        
 

        g = sns.FacetGrid(pars_df_formatted, col="parameter", height=5, sharey=False);
        g = g.map(errorplot, 'subject', 'value').add_legend();     
        g.fig.savefig(datapath_out + '/parameter_participant_fit-' + fitting_agent_key + '_' + subject_key + '.jpg')
        
        g = sns.FacetGrid(pars_df_formatted, col="parameter", height=5, sharey=False, sharex=False, palette='Set1'); 
        g = g.map(sns.kdeplot, 'value').add_legend();        
        g.fig.savefig(datapath_out + '/post_group_parameters_fit-' + fitting_agent_key + '_' + subject_key + '.pdf', dpi=300)

        pars_df_formatted['IDs'] = np.array(ids_testlogs)[pars_df_formatted.subject.values - 1]                    
        pars_df_formatted.to_csv(datapath_out + '/pars_post_samples_fit-' + fitting_agent_key + '_' + subject_key + '.csv')

        
        pseudo_rsquare_120_mean, BIC_120_mean, \
           pseudo_rsquare_hinoise_120_mean, BIC_hinoise_120, \
           pseudo_rsquare_lonoise_120_mean, BIC_lonoise_120, \
           pseudo_rsquare_single_mean, BIC_single_mean, raw_probs_single_mean, \
           nll_firstaction_mean = calc_BIC_SAT_UP_logfiles(infer, responses_testlogs, conditions_testlogs, m_prob) 
        modelfit['fit-' + fitting_agent_key][ 'sim-' + subject_key]['pseudo_rsquare_120_mean'] = pseudo_rsquare_120_mean
        modelfit['fit-' + fitting_agent_key][ 'sim-' + subject_key]['BIC_120_mean'] = BIC_120_mean        
      
        df_BIC_rhosq = pd.DataFrame(data=modelfit['fit-' + fitting_agent_key][ 'sim-' + subject_key])
        df_BIC_rhosq['ID'] = ids_testlogs
        df_BIC_rhosq.to_csv(datapath_out + '/Modelfit_' + fitting_agent_key + '_' + subject_key + '_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp.csv') 

        modelfit_per_miniblock['fit-' + fitting_agent_key][ 'sim-' + subject_key]['raw_probs_single_mean'] = np.reshape(raw_probs_single_mean, (1, len(ids_testlogs) * 144))[0]
        modelfit_per_miniblock['fit-' + fitting_agent_key][ 'sim-' + subject_key]['pseudo_rsquare_single_mean'] = np.reshape(pseudo_rsquare_single_mean, (1, len(ids_testlogs) * 144))[0]        
        modelfit_per_miniblock['fit-' + fitting_agent_key][ 'sim-' + subject_key]['BIC_single_mean'] = np.reshape(BIC_single_mean, (1, len(ids_testlogs) * 144))[0]                
        modelfit_per_miniblock['fit-' + fitting_agent_key][ 'sim-' + subject_key]['nll_firstaction_mean'] = np.reshape(nll_firstaction_mean, (1, len(ids_testlogs) * 144))[0]        
        df_fit_per_miniblock = pd.DataFrame(data=modelfit_per_miniblock['fit-' + fitting_agent_key][ 'sim-' + subject_key])
        df_fit_per_miniblock['ID'] = np.repeat(ids_testlogs, 144)
        df_fit_per_miniblock.to_csv(datapath_out + '/Modelfit_per_miniblock_' + fitting_agent_key + '_' + subject_key + '_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp.csv') 



np.savez(datapath_out + '/modelfit-SAT-UP_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', modelfit) 
np.savez(datapath_out + '/pars_df-SAT-UP_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', pars_df) 


