"""
@author: Lorenz Goenner
"""

import numpy as np

def calc_BIC_SAT_UP_logfiles(inferrer, responses, conditions, m_prob, n_actions_considered = 1):
    # Evaluate (log-)likelihood of actual choices, given the inferred model parameters:    
    n_subj = len(responses)
    n_miniblocks = responses.shape[1]
    nll_firstaction_mean = np.nan * np.ones([n_subj, n_miniblocks])    
    nll_firstaction_depths = np.nan * np.ones([n_subj, n_miniblocks, 3])
    nll_hinoise_144_mean = np.nan * np.ones([n_subj])
    nll_lonoise_144_mean = np.nan * np.ones([n_subj])
    nll_144_mean = np.nan * np.ones([n_subj])
    pseudo_rsquare_144_mean = np.nan * np.ones([n_subj])
    pseudo_rsquare_single_mean = np.nan * np.ones([n_subj, n_miniblocks])    
    m_param_count = inferrer.agent.np
    BIC_144_mean = np.nan * np.ones([n_subj])
    BIC_single_mean = np.nan * np.ones([n_subj, n_miniblocks])     
    raw_probs_single_mean = np.nan * np.ones([n_subj, n_miniblocks])    
    
    training_blocks = 0 # in case you want to exclude the first couple of mini-blocks as "training"


    for i_subj in range(n_subj):
        for i_mblk in range(n_miniblocks):
            for i_action in range(n_actions_considered): # Consider only first action; use range(3) to consider all action steps
               
                logits_depths = inferrer.agent.logits[3*i_mblk + i_action].detach().numpy() # agent.logits = Value difference between Jump and Move             

                resp = inferrer.responses[i_subj][i_mblk].numpy()[i_action] 

                p_jump_depths = 1.0 / (1 + np.exp(-logits_depths[i_subj])) # softmax function for choice probabilities
                p_move_depths = 1 - p_jump_depths
                if resp==1:
                    if np.min(p_jump_depths) > 0:
                        nll = -np.log(p_jump_depths) # Apply -np.log() to obtain the negative log-likelihood (nll), for numerical reasons
                    else:
                        nll = -np.log(p_jump_depths + np.finfo(np.float64).eps)  # Avoid inf values                      
                elif resp==0:
                    if np.min(p_move_depths) > 0:                    
                        nll = -np.log(p_move_depths)                              
                    else:
                        nll = -np.log(p_move_depths + np.finfo(np.float64).eps)   

                nll_firstaction_depths[i_subj, i_mblk, :] = nll              
                nll_firstaction_mean[i_subj, i_mblk] = np.matmul(nll_firstaction_depths[i_subj, i_mblk, :], m_prob[0][i_mblk, i_subj, :]) 

        nll_hinoise_144_mean[i_subj] = np.matmul(nll_firstaction_mean[i_subj, training_blocks:].transpose(), conditions[0][i_subj, training_blocks:].numpy()) 
        nll_lonoise_144_mean[i_subj] = np.matmul(nll_firstaction_mean[i_subj, training_blocks:].transpose(), 1 - conditions[0][i_subj, training_blocks:].numpy()) 
        nll_144_mean[i_subj] = nll_hinoise_144_mean[i_subj] + nll_lonoise_144_mean[i_subj]

        nll_random_144 = -np.log(0.5)*144 * n_actions_considered
        nll_random_72 = -np.log(0.5)*72 * n_actions_considered    
        nll_random_1 = -np.log(0.5)*1 * n_actions_considered # for single miniblocks                
        pseudo_rsquare_144_mean[i_subj] = 1 - (nll_144_mean[i_subj] / nll_random_144)            
        pseudo_rsquare_single_mean[i_subj, :] = 1 - (nll_firstaction_mean[i_subj, :] / nll_random_1)     
        raw_probs_single_mean[i_subj, :] = np.exp(- nll_firstaction_mean[i_subj, :])           

        BIC_144_mean[i_subj] = 2*nll_144_mean[i_subj] + m_param_count*np.log(144 * n_actions_considered)
        BIC_single_mean[i_subj] = 2*nll_firstaction_mean[i_subj, :] + m_param_count*np.log(144 * n_actions_considered) 
                
    return pseudo_rsquare_144_mean, BIC_144_mean, \
           pseudo_rsquare_single_mean, BIC_single_mean, \
           raw_probs_single_mean, nll_firstaction_mean