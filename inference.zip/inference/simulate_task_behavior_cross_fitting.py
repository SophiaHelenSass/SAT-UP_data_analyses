"""
@authors: Lorenz Goenner

"""
import numpy as np
import matplotlib.pyplot as plt
import pylab as plt
import torch
import pyro
import seaborn as sns
import sys
import scipy.io as io
import json
import scipy.stats as st
import pandas as pd

sys.path.append('../')

from tasks_pruning import SpaceAdventurePruning
from agents_pruning_task_rational_noalpha import BackInductionSAT_UP_Rational_noalpha
from agents_pruning_task_lowprobpruning import BackInductionSAT_UP_LowprobPruning
from agents_pruning_task_discounting_lowprobpruning_kmax30 import BackInductionSAT_UP_Discounting_LowprobPruning_kmax30
from simulate import Simulator
from inference import Inferrer
from helper_files import get_posterior_stats
from calc_BIC import calc_BIC_SAT_UP_logfiles

from scipy.stats import mode

# In[1]:  #### agent simulation and recovery for SAT UP ###########################################
# set global variables
pyro.enable_validation(True)

sns.set(context='talk', style='white', color_codes=True)

runs0 = 100            #number of simulations (agents)
mini_blocks0 = 144     #number of mini-blocks
max_trials0 = 3        #maximum number of actions per mini-block
max_depth0 = 3         #maximum planning depth
na0 = 2                #number of actions
ns0 = 6                #number of states
no0 = 5                #number of outcomes
starting_points = 350  #number of points at the beginning of task

# load task configuration file 
read_file = open('config_file_2.json',"r")
exp1 = json.load(read_file)
read_file.close()

config_path = ''
config_file_bothcond = 'config_file_main.csv'

version_label_str = 'SAT_UP_publication' 

config_both_conditions = pd.read_csv(config_path + config_file_bothcond)

# load starting positions of each mini-block 
starts0_new = config_both_conditions.start_pos
starts0_new = np.asarray(starts0_new)
starts0_new = starts0_new -1

n_miniblocks_new = 144 

planets_new_points = np.nan * np.ones([n_miniblocks_new, 6])
planets_new_index = [] 

for i in range(n_miniblocks_new):
    planets_new_points[i] = [config_both_conditions.planet1[i], config_both_conditions.planet2[i], config_both_conditions.planet3[i], \
                      config_both_conditions.planet4[i], config_both_conditions.planet5[i], config_both_conditions.planet6[i]]
    
# mapping needed from [-20, -10, 0, 10, 20] to [0,1,2,3,4]:
planets_new_index = np.int0( (planets_new_points + 20) / 10 )

vect0_new = np.eye(5)[planets_new_index]

ol0_new = torch.from_numpy(vect0_new)

starts0_new = torch.from_numpy(starts0_new)

# load planet uncertain planet optimal condition
noise0 = exp1['conditionsExp']['noise']
for i in range(len(noise0)):
  if noise0[i] == 'high':
    noise0[i] = 1

for i in range(len(noise0)):
  if noise0[i] == 'low':
    noise0[i] = 0
    
noise0_new = config_both_conditions.uncertain_planet
    
noise0 = np.asarray(noise0)
noise0 = noise0[20:140]

noise0_new = np.asarray(noise0_new - 1) # Conversion from matlab to python indexing

# number of actions for each mini-block 
trials0_new = np.int0(3*np.ones(n_miniblocks_new))

# load action costs (all zero)
costs0 = np.asarray(exp1['actionCost'])
costs0 = torch.FloatTensor(costs0)

# load fuel rewards/punishment for each planet type [-20,-10,0,10,20]
fuel0 = np.asarray(exp1['planetRewards'])
fuel0 = torch.FloatTensor(fuel0)  

confs0_new = ol0_new.repeat(runs0,1,1,1).float()

# build tensors for conditions described by number of actions and noise condition
conditions0_new = torch.zeros(3, runs0, n_miniblocks_new, dtype=torch.long)
conditions0_new[0] = torch.tensor(np.append(noise0[0:72], noise0[0:72]), dtype=torch.long)[None, :] 
conditions0_new[1] = torch.tensor(trials0_new, dtype=torch.long)
conditions0_new[2] = torch.tensor(noise0_new, dtype=torch.long)[None, :]

simulations = {}
simulations['rational'] = []
simulations['lowprob_pruning'] = []
simulations['random'] = []
simulations['discounting_kappa10_lowprob_pruning'] = []

performance = {}
performance['rational'] = []
performance['lowprob_pruning'] = []
performance['random'] = []
performance['discounting_kappa10_lowprob_pruning'] = []

trans_pars_depth = {}
trans_pars_depth['rational'] = []
trans_pars_depth['lowprob_pruning'] = []
trans_pars_depth['random'] = []
trans_pars_depth['discounting_kappa10_lowprob_pruning'] = []

points_depth = {}
points_depth['rational'] = []
points_depth['lowprob_pruning'] = []
points_depth['random'] = []
points_depth['discounting_kappa10_lowprob_pruning'] = []

responses_depth = {}
responses_depth['rational'] = []
responses_depth['lowprob_pruning'] = []
responses_depth['random'] = []
responses_depth['discounting_kappa10_lowprob_pruning'] = []

final_points = {}
final_points['rational'] = []
final_points['lowprob_pruning'] = []
final_points['random'] = []
final_points['discounting_kappa10_lowprob_pruning'] = []

states = {}
states['rational'] = []
states['lowprob_pruning'] = []
states['random'] = []
states['discounting_kappa10_lowprob_pruning'] = []

# In[2]
datapath = ''

agents = {}

m0 = {} # mean parameter values
trans_pars0 = {}

# Simulations
for agent_key in ['rational', 'lowprob_pruning', 'discounting_kappa10_lowprob_pruning','random']:
    
    for i in range(3): # 
    # define space adventure task with aquired configurations
    # set number of trials to the max number of actions per mini-block
        space_advent0 = SpaceAdventurePruning(conditions0_new,
                                  outcome_likelihoods=confs0_new,
                                  init_states=starts0_new,
                                  runs=runs0,
                                  mini_blocks=n_miniblocks_new,
                                  trials=3)

    # define the optimal agent, each with a different maximal planning depth
        if agent_key == 'rational':    
            agents['rational'] = BackInductionSAT_UP_Rational_noalpha(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=i+1)

            # set beta, theta and alpha parameters as a normal distribution around a certain value
            
            m0['rational'] = torch.tensor([1.1, 0.]) # means: beta = ~3--> exp(1.1); theta = 0

        elif agent_key == 'lowprob_pruning':    
            agents['lowprob_pruning'] = BackInductionSAT_UP_LowprobPruning(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=i+1)

            # set beta, theta and alpha parameters as a normal distribution around a certain value
           
            m0['lowprob_pruning'] = torch.tensor([1.2, 0.]) # means: beta = ~3--> exp(1.1); theta = 0

 
    
        elif agent_key == 'random':    
            agents['random'] = BackInductionSAT_UP_Rational_noalpha(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=i+1)
           
            m0['random'] = torch.tensor([-10, 0.]) # beta close to zero       
    
      
        elif agent_key == 'discounting_kappa10_lowprob_pruning':    
            agents['discounting_kappa10_lowprob_pruning'] = BackInductionSAT_UP_Discounting_LowprobPruning_kmax30(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=i+1)
           
            m0['discounting_kappa10_lowprob_pruning'] = torch.tensor([1.1, 0.,-0.7 ]) # mean beta = ~3# np.exp(1.1) = 10,  k=10 = 30*sigmoid(-0.7)


        trans_pars0[agent_key] = torch.distributions.Normal(m0[agent_key], 0.1).sample((runs0,))
        agents[agent_key].set_parameters(trans_pars0[agent_key])
     
  
    # simulate behavior
        sim0 = Simulator(space_advent0,
                    agents[agent_key],
                    runs=runs0,
                    mini_blocks=n_miniblocks_new,
                    trials=3)
        sim0.simulate_experiment()

        simulations[agent_key].append(sim0)
        
        states[agent_key].append(space_advent0.states.clone())

        responses0 = simulations[agent_key][-1].responses.clone() #response actions in simulation for every mini-block 
        responses0[torch.isnan(responses0)] = -1.
        responses0 = responses0.long()
        points0 = (costs0[responses0] + fuel0[simulations[agent_key][-1].outcomes])  #reward for landing on a certain planet in simulation

        points0[simulations[agent_key][-1].outcomes < 0] = 0 
        performance[agent_key].append(points0.sum(dim=-1))   #sum up the gains 
    
        trans_pars_depth[agent_key].append(trans_pars0[agent_key])
        points_depth[agent_key].append(points0)
        responses_depth[agent_key].append(responses0)

        final_points[agent_key].append(points_depth[agent_key][i][:,:,:].numpy().sum(2).sum(1).mean())
 


    dict_mb_gain = {}
    dict_mb_gain['Mean_gain_PD3'] = points_depth[agent_key][2][:,:,:].numpy().sum(2).mean(0)
    dict_mb_gain['Std_gain_PD3'] = points_depth[agent_key][2][:,:,:].numpy().sum(2).std(0)
    dict_mb_gain['Mean_gain_PD2'] = points_depth[agent_key][1][:,:,:].numpy().sum(2).mean(0)
    dict_mb_gain['Std_gain_PD2'] = points_depth[agent_key][1][:,:,:].numpy().sum(2).std(0)
    dict_mb_gain['Mean_gain_PD1'] = points_depth[agent_key][0][:,:,:].numpy().sum(2).mean(0)
    dict_mb_gain['Std_gain_PD1'] = points_depth[agent_key][0][:,:,:].numpy().sum(2).std(0)
    df_mean_std_permb = pd.DataFrame(data=dict_mb_gain)
    df_mean_std_permb.to_csv(datapath + '/miniblock_gain_mean_std_'+agent_key+'_'+str(runs0)+'.csv')
 


# save random performance per mini block 
random_performance = performance['random'][0].numpy()
df = pd.DataFrame(random_performance) 
df.to_csv(datapath + '/miniblock_gain_per_agent_random_'+str(runs0)+'.csv', index=False)

PD1_performance = performance['rational'][0].numpy()
df = pd.DataFrame(PD1_performance) 
df.to_csv(datapath + '/miniblock_gain_per_agent_rational_PD1_'+str(runs0)+'.csv', index=False)


# read out action choices for rational model (add other models later)
rational_list = responses_depth['rational']
PD3_actions_rational = rational_list[0].numpy()
PD3_actions_rational = np.mean(PD3_actions_rational, axis=0)
PD3_actions_rational = pd.DataFrame(PD3_actions_rational) 
PD3_actions_rational.to_csv(datapath + '/miniblock_action_choices_PD3_rational_'+str(runs0)+'.csv', index=False)


# read out action choices for discounting_gamma0.1 model 
lowprob_pruning_list = responses_depth['lowprob_pruning']
PD3_actions_lowprob_pruning = lowprob_pruning_list[0].numpy()
PD3_actions_lowprob_pruning = np.mean(PD3_actions_lowprob_pruning, axis=0)
PD3_actions_lowprob_pruning = pd.DataFrame(PD3_actions_lowprob_pruning) 
PD3_actions_lowprob_pruning.to_csv(datapath + '/miniblock_action_choices_PD3_lowprob_pruning_'+str(runs0)+'.csv', index=False)



# read out action choices for discounting_gamma0.7 model 
discounting_gamma_lowprob_pruning_list = responses_depth['discounting_kappa10_lowprob_pruning']
PD3_actions_discounting_gamma_lowprob_pruning = discounting_gamma_lowprob_pruning_list[0].numpy()
PD3_actions_discounting_gamma_lowprob_pruning = np.mean(PD3_actions_discounting_gamma_lowprob_pruning, axis=0)
PD3_actions_discounting_gamma_lowprob_pruning = pd.DataFrame(PD3_actions_discounting_gamma_lowprob_pruning) 
PD3_actions_discounting_gamma_lowprob_pruning.to_csv(datapath + '/miniblock_action_choices_PD3_discounting_kappa10_lowprob_pruning_'+str(runs0)+'.csv', index=False)




# In[3]

sim_number0 = 2                                    
            
agent2_rational = {}
agent2_pruning = {}

fitting_agents = {}
elbo = {}
modelfit = {}

pars_df = {}

fitting_agent_keys = ['rational','lowprob_pruning', 'discounting_kappa10_lowprob_pruning']
sim_agent_keys = ['rational','lowprob_pruning', 'discounting_kappa10_lowprob_pruning']
n_iter = 500 
n_samples = 100 

for fitting_agent_key in fitting_agent_keys:
    
    fitting_agents['fit-' + fitting_agent_key] = {}
    elbo['fit-' + fitting_agent_key] = {}        
    modelfit['fit-' + fitting_agent_key] = {}             

    pars_df['fit-' + fitting_agent_key] = {}            
    
    for simulated_agent_key in sim_agent_keys: # , 
        print()    
        print('fitted: '+fitting_agent_key + ', simulated: '+simulated_agent_key)     
    
        fitting_agents['fit-'+fitting_agent_key][ 'sim-'+simulated_agent_key ] = {} 
        modelfit['fit-'+fitting_agent_key][ 'sim-'+simulated_agent_key ] = {}    
    
        responses0 = simulations[simulated_agent_key][sim_number0].responses.clone()
        mask0 = ~torch.isnan(responses0)

        stimuli0 = {'conditions': conditions0_new,
           'states': states[simulated_agent_key][sim_number0],
           'configs': confs0_new}

        if fitting_agent_key == 'rational':
            fitting_agents['fit-rational']['sim-' + simulated_agent_key] = BackInductionSAT_UP_Rational_noalpha(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=3)
            

        elif fitting_agent_key == 'lowprob_pruning':        
            fitting_agents['fit-lowprob_pruning']['sim-' + simulated_agent_key]= BackInductionSAT_UP_LowprobPruning(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=3)     
            
        
        elif fitting_agent_key == 'discounting_kappa10_lowprob_pruning':        
            fitting_agents['fit-discounting_kappa10_lowprob_pruning']['sim-' + simulated_agent_key]= BackInductionSAT_UP_Discounting_LowprobPruning_kmax30(confs0_new,
                          runs=runs0,
                          mini_blocks=n_miniblocks_new,
                          trials=3,
                          costs = torch.tensor([0., 0.]), 
                          planning_depth=3)       
            
              
        if fitting_agent_key == 'rational':
            infer = Inferrer(fitting_agents['fit-rational']['sim-' + simulated_agent_key], stimuli0, responses0, mask0)
            infer.fit(num_iterations=n_iter, num_particles=100, optim_kwargs={'lr': 0.02}) # change the number of iterations here if you like
            labels = [r'$\tilde{\beta}$', r'$\theta$']          
            labels_rational = labels
            
      
        elif fitting_agent_key == 'lowprob_pruning':
            infer = Inferrer(fitting_agents['fit-lowprob_pruning']['sim-' + simulated_agent_key], stimuli0, responses0, mask0)
            infer.fit(num_iterations=n_iter, num_particles=100, optim_kwargs={'lr': 0.02})  # change the number of iterations here if you like
            labels = [r'$\tilde{\beta}$', r'$\theta$'] 
            labels_lowprob_pruning = labels                     
            
       
        elif fitting_agent_key == 'discounting_kappa10_lowprob_pruning':    
            infer = Inferrer(fitting_agents['fit-discounting_kappa10_lowprob_pruning']['sim-' + simulated_agent_key], stimuli0, responses0, mask0)
            infer.fit(num_iterations=n_iter, num_particles=100, optim_kwargs={'lr': 0.02}) # change the number of iterations here if you like
            labels = [r'$\tilde{\beta}$', r'$\theta$', r'$k$']                       
            labels_lowprob_pruning_discounting = labels
       
        elbo['fit-'+fitting_agent_key][ 'sim-' + simulated_agent_key ] = infer.loss[:]
        post_marg = infer.sample_posterior_marginal(n_samples=n_samples)        
        post_depth, m_prob, exc_count = get_posterior_stats(post_marg, mini_blocks = 144)
        np.savez(datapath + '/plandepth_stats_pilot2_fit-' + fitting_agent_key+'_sim-'+simulated_agent_key+'_'+str(runs0)+'runs_'+str(n_iter)+'iter', post_depth, m_prob, exc_count)
        
        pars_df['fit-' + fitting_agent_key]['sim-' + simulated_agent_key], mg_df, sg_df = infer.sample_from_posterior(labels, n_samples=100) # 100
        
             
        pseudo_rsquare_120_mean, BIC_120_mean, \
           pseudo_rsquare_hinoise_120_mean, BIC_hinoise_120, \
           pseudo_rsquare_lonoise_120_mean, BIC_lonoise_120, \
           pseudo_rsquare_single_mean, BIC_single_mean, raw_probs_single_mean, \
           nll_firstaction_mean = calc_BIC_SAT_UP_logfiles(infer, responses0, conditions0_new, m_prob) 
        modelfit['fit-' + fitting_agent_key][ 'sim-' + simulated_agent_key]['pseudo_rsquare_120_mean'] = pseudo_rsquare_120_mean
        modelfit['fit-' + fitting_agent_key][ 'sim-' + simulated_agent_key]['BIC_120_mean'] = BIC_120_mean        
        

np.savez(datapath + '/modelfit-SAT-UP_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', modelfit)
np.savez(datapath + '/elbo-SAT-UP'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', elbo)
np.savez(datapath + '/responses_depth-SAT-UP'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', responses_depth)
np.savez(datapath + '/states-SAT-UP'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', states)
np.savez(datapath + '/m0_params-SAT-UP'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', m0)
np.savez(datapath + '/trans_pars_depth-SAT-UP'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp', trans_pars_depth)



# Confusion matrix: See Wilson & Collins 2019, eLife
confusion_mat_BIC = np.nan * np.ones([len(sim_agent_keys), len(fitting_agent_keys)]) # p(fit | sim) - Probability that a given fitted model fits a given simulated model best, based on BIC

inversion_mat_BIC = np.nan * np.ones([len(sim_agent_keys), len(fitting_agent_keys)]) # p(sim | fit) - Confidence that data resulted from a given simulated model, given a certain best-fitting model based on BIC

confusion_mat_rhosq = np.nan * np.ones([len(sim_agent_keys), len(fitting_agent_keys)]) # p(fit | sim) - Probability that a given fitted model fits a given simulated model best, based on rhosquare

inversion_mat_rhosq = np.nan * np.ones([len(sim_agent_keys), len(fitting_agent_keys)]) # p(sim | fit) - Confidence that data resulted from a given simulated model, given a certain best-fitting model based on rhosquare


for i_simulated in range(len(sim_agent_keys)):
    sim_model = 'sim-' + sim_agent_keys[i_simulated]
        
    for i_fitted in range(len(fitting_agent_keys)):
        fit_model = 'fit-' + fitting_agent_keys[i_fitted]        
            
        nanmin_BIC_120_mean = np.nanmin(np.array([
                             modelfit['fit-'+fitting_agent_keys[0]][sim_model]['BIC_120_mean'], \
                             modelfit['fit-'+fitting_agent_keys[1]][sim_model]['BIC_120_mean'], \
                             modelfit['fit-'+fitting_agent_keys[2]][sim_model]['BIC_120_mean']]), 0)            
          
            
        nanmax_rhosquare_120_mean = np.nanmax(np.array([
                             modelfit['fit-'+fitting_agent_keys[0]][sim_model]['pseudo_rsquare_120_mean'], \
                             modelfit['fit-'+fitting_agent_keys[1]][sim_model]['pseudo_rsquare_120_mean'], \
                             modelfit['fit-'+fitting_agent_keys[2]][sim_model]['pseudo_rsquare_120_mean']]), 0)   

  
            
        n_valid_model_fits_BIC_120_mean = float( runs0 - np.sum(np.isnan(nanmin_BIC_120_mean)))        
                      
        
        confusion_mat_BIC[i_simulated, i_fitted] = sum(modelfit[fit_model][sim_model]['BIC_120_mean'] <= \
                                                       nanmin_BIC_120_mean) / n_valid_model_fits_BIC_120_mean

        n_valid_model_fits_rhosquare_120_mean = float( runs0 - np.sum(np.isnan(nanmax_rhosquare_120_mean)))        
     
        confusion_mat_rhosq[i_simulated, i_fitted] = sum(modelfit[fit_model][sim_model]['pseudo_rsquare_120_mean'] >= \
                                                         nanmax_rhosquare_120_mean) / n_valid_model_fits_rhosquare_120_mean
       
for i_fitted in range(len(fitting_agent_keys)):    
    for i_simulated in range(len(sim_agent_keys)):    
        inversion_mat_BIC[i_simulated, i_fitted] = confusion_mat_BIC[i_simulated, i_fitted] / np.sum(confusion_mat_BIC[:, i_fitted])
        
        inversion_mat_rhosq[i_simulated, i_fitted] = confusion_mat_rhosq[i_simulated, i_fitted] / np.sum(confusion_mat_rhosq[:, i_fitted])        
      

def plot_confusion_inversion_matrix(matrix, \
                                    title, \
                                     x_labels, \
                                     y_labels, \
                                     filename):    
    plt.figure(dpi=150)
    plt.matshow(matrix, cmap='viridis', fignum=False) # 
    fsize = 20
    #plt.colorbar()
    for i in range(len(fitting_agent_keys)):
        for j in range(len(fitting_agent_keys)):
            if matrix[i,j] >= 0.5:
                plt.text(j-0.2, i, str(np.round(matrix[i,j], 2)), fontsize=fsize)
            else:
                plt.text(j-0.2, i, str(np.round(matrix[i,j], 2)), fontsize=fsize, color='white')        
    plt.xlabel('best-fitting model')            
    plt.ylabel('simulated model')   
    plt.title(title)       
    ax=plt.gca()
    ax.set_xticklabels(x_labels)
    ax.set_yticklabels(y_labels)
    plt.gcf().set_size_inches(11, 8)    
    plt.tight_layout()
    plt.savefig(filename, dpi=150)
    return


str_model1 = 'Full-breadth planning'
str_model2 = 'Low-probability \n pruning'
str_model3 = 'Hyperbolic \n discounting \n low-probability \n pruning'
comparison_label = 'publication_models_pilot3'

plot_confusion_inversion_matrix(confusion_mat_BIC, \
                                'Confusion matrix based on BIC: \n  p(best-fitting model | simulated model)', \
                                ['', str_model1, str_model2, str_model3], \
                                ['', str_model1, str_model2, str_model3], \
                                datapath + '/confusion_mat_BIC_' + comparison_label + '_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp.png')

plot_confusion_inversion_matrix(inversion_mat_BIC, \
                                'Inversion matrix based on BIC: \n  p(simulated model | best-fitting model)', \
                                ['', str_model1, str_model2, str_model3], \
                                ['', str_model1, str_model2, str_model3], \
                                datapath + '/inversion_mat_BIC_' + comparison_label + '_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp.png')
  
    
plot_confusion_inversion_matrix(confusion_mat_rhosq, \
                                'Confusion matrix based on rhosquare: \n  p(best-fitting model | simulated model)', \
                                ['', str_model1, str_model2, str_model3], \
                                ['', str_model1, str_model2, str_model3], \
                                datapath + '/confusion_mat_rhosquare_' + comparison_label + '_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp.png')

plot_confusion_inversion_matrix(inversion_mat_rhosq, \
                                'Inversion matrix based on rhosquare: \n  p(simulated model | best-fitting model)', \
                                ['', str_model1, str_model2, str_model3], \
                                ['', str_model1, str_model2, str_model3], \
                                datapath + '/inversion_mat_rhosquare_' + comparison_label + '_'+str(runs0)+'runs_'+str(n_iter)+'iter_'+str(n_samples)+'samp.png')



