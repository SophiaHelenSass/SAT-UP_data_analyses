# by Sophia-Helen Sass (2025)
# concatenate long data sets 

# prepare workspace, load data, concatenate data ####
# clear workspace
rm(list = ls())

#set working and data directory
setwd("")

# most recent data version here
  B3_SAT_long <- rbind(B3_SAT_long1<-read.csv('B3_SAT_long_144trials_public001.csv', header=TRUE),
  B3_SAT_long2<-read.csv('B3_SAT_long_144trials_public002.csv', header=TRUE),
  B3_SAT_long3<-read.csv('B3_SAT_long_144trials_public003.csv', header=TRUE),
  B3_SAT_long4<-read.csv('B3_SAT_long_144trials_public004.csv', header=TRUE),
  B3_SAT_long6<-read.csv('B3_SAT_long_144trials_public006.csv', header=TRUE),
  B3_SAT_long7<-read.csv('B3_SAT_long_144trials_public007.csv', header=TRUE),
  B3_SAT_long9<-read.csv('B3_SAT_long_144trials_public009.csv', header=TRUE),
  B3_SAT_long10<-read.csv('B3_SAT_long_144trials_public010.csv', header=TRUE),
  B3_SAT_long11<-read.csv('B3_SAT_long_144trials_public011.csv', header=TRUE),
  B3_SAT_long12<-read.csv('B3_SAT_long_144trials_public012.csv', header=TRUE),
  B3_SAT_long13<-read.csv('B3_SAT_long_144trials_public013.csv', header=TRUE),
  B3_SAT_long15<-read.csv('B3_SAT_long_144trials_public015.csv', header=TRUE),
  B3_SAT_long16<-read.csv('B3_SAT_long_144trials_public016.csv', header=TRUE),
  B3_SAT_long17<-read.csv('B3_SAT_long_144trials_public017.csv', header=TRUE),
  B3_SAT_long18<-read.csv('B3_SAT_long_144trials_public018.csv', header=TRUE),
  B3_SAT_long19<-read.csv('B3_SAT_long_144trials_public019.csv', header=TRUE),
  B3_SAT_long20<-read.csv('B3_SAT_long_144trials_public020.csv', header=TRUE),
  B3_SAT_long21<-read.csv('B3_SAT_long_144trials_public021.csv', header=TRUE),
  B3_SAT_long22<-read.csv('B3_SAT_long_144trials_public022.csv', header=TRUE),
  B3_SAT_long23<-read.csv('B3_SAT_long_144trials_public023.csv', header=TRUE),
  B3_SAT_long24<-read.csv('B3_SAT_long_144trials_public024.csv', header=TRUE),
  B3_SAT_long26<-read.csv('B3_SAT_long_144trials_public026.csv', header=TRUE),
  B3_SAT_long27<-read.csv('B3_SAT_long_144trials_public027.csv', header=TRUE),
  B3_SAT_long28<-read.csv('B3_SAT_long_144trials_public028.csv', header=TRUE),
  B3_SAT_long29<-read.csv('B3_SAT_long_144trials_public029.csv', header=TRUE),
  B3_SAT_long30<-read.csv('B3_SAT_long_144trials_public030.csv', header=TRUE),
  B3_SAT_long31<-read.csv('B3_SAT_long_144trials_public031.csv', header=TRUE),
  B3_SAT_long32<-read.csv('B3_SAT_long_144trials_public032.csv', header=TRUE),
  B3_SAT_long34<-read.csv('B3_SAT_long_144trials_public034.csv', header=TRUE),
  B3_SAT_long35<-read.csv('B3_SAT_long_144trials_public035.csv', header=TRUE),
  B3_SAT_long36<-read.csv('B3_SAT_long_144trials_public036.csv', header=TRUE),
  B3_SAT_long37<-read.csv('B3_SAT_long_144trials_public037.csv', header=TRUE),
  B3_SAT_long38<-read.csv('B3_SAT_long_144trials_public038.csv', header=TRUE),
  B3_SAT_long39<-read.csv('B3_SAT_long_144trials_public039.csv', header=TRUE),
  B3_SAT_long40<-read.csv('B3_SAT_long_144trials_public040.csv', header=TRUE),
  B3_SAT_long41<-read.csv('B3_SAT_long_144trials_public041.csv', header=TRUE),
  B3_SAT_long42<-read.csv('B3_SAT_long_144trials_public042.csv', header=TRUE),
  B3_SAT_long43<-read.csv('B3_SAT_long_144trials_public043.csv', header=TRUE),
  B3_SAT_long44<-read.csv('B3_SAT_long_144trials_public044.csv', header=TRUE),
  B3_SAT_long45<-read.csv('B3_SAT_long_144trials_public045.csv', header=TRUE),
  B3_SAT_long46<-read.csv('B3_SAT_long_144trials_public046.csv', header=TRUE),
  B3_SAT_long47<-read.csv('B3_SAT_long_144trials_public047.csv', header=TRUE),
  B3_SAT_long48<-read.csv('B3_SAT_long_144trials_public048.csv', header=TRUE),
  B3_SAT_long49<-read.csv('B3_SAT_long_144trials_public049.csv', header=TRUE),
  B3_SAT_long50<-read.csv('B3_SAT_long_144trials_public050.csv', header=TRUE),
  B3_SAT_long52<-read.csv('B3_SAT_long_144trials_public052.csv', header=TRUE),
  B3_SAT_long53<-read.csv('B3_SAT_long_144trials_public053.csv', header=TRUE),
  B3_SAT_long54<-read.csv('B3_SAT_long_144trials_public054.csv', header=TRUE),
  B3_SAT_long55<-read.csv('B3_SAT_long_144trials_public055.csv', header=TRUE),
  B3_SAT_long56<-read.csv('B3_SAT_long_144trials_public056.csv', header=TRUE),
  B3_SAT_long57<-read.csv('B3_SAT_long_144trials_public057.csv', header=TRUE),
  B3_SAT_long58<-read.csv('B3_SAT_long_144trials_public058.csv', header=TRUE), 
  B3_SAT_long59<-read.csv('B3_SAT_long_144trials_public059.csv', header=TRUE),
  B3_SAT_long1001<-read.csv('B3_SAT_long_144trials_public1001.csv', header=TRUE),
  B3_SAT_long1002<-read.csv('B3_SAT_long_144trials_public1002.csv', header=TRUE),
  B3_SAT_long1004<-read.csv('B3_SAT_long_144trials_public1004.csv', header=TRUE),
  B3_SAT_long1005<-read.csv('B3_SAT_long_144trials_public1005.csv', header=TRUE),
  B3_SAT_long1006<-read.csv('B3_SAT_long_144trials_public1006.csv', header=TRUE),
  B3_SAT_long1007<-read.csv('B3_SAT_long_144trials_public1007.csv', header=TRUE),
  B3_SAT_long1008<-read.csv('B3_SAT_long_144trials_public1008.csv', header=TRUE),
  B3_SAT_long1009<-read.csv('B3_SAT_long_144trials_public1009.csv', header=TRUE),
  B3_SAT_long1010<-read.csv('B3_SAT_long_144trials_public1010.csv', header=TRUE),
  B3_SAT_long1011<-read.csv('B3_SAT_long_144trials_public1011.csv', header=TRUE),
  B3_SAT_long1012<-read.csv('B3_SAT_long_144trials_public1012.csv', header=TRUE),
  B3_SAT_long1013<-read.csv('B3_SAT_long_144trials_public1013.csv', header=TRUE),
  B3_SAT_long1014<-read.csv('B3_SAT_long_144trials_public1014.csv', header=TRUE),
  B3_SAT_long1015<-read.csv('B3_SAT_long_144trials_public1015.csv', header=TRUE),
  B3_SAT_long1016<-read.csv('B3_SAT_long_144trials_public1016.csv', header=TRUE),
  B3_SAT_long1017<-read.csv('B3_SAT_long_144trials_public1017.csv', header=TRUE),
  B3_SAT_long1019<-read.csv('B3_SAT_long_144trials_public1019.csv', header=TRUE),
  B3_SAT_long1020<-read.csv('B3_SAT_long_144trials_public1020.csv', header=TRUE),
  B3_SAT_long1022<-read.csv('B3_SAT_long_144trials_public1022.csv', header=TRUE),
  B3_SAT_long1023<-read.csv('B3_SAT_long_144trials_public1023.csv', header=TRUE),
  B3_SAT_long1024<-read.csv('B3_SAT_long_144trials_public1024.csv', header=TRUE))

  # save data as csv ####
  savedir = ("")
  path_C <- paste0(savedir, "/B3_SAT_long_144trials_public",".csv", sep="")
  write.csv(B3_SAT_long, file=path_C, row.names=F)
  
 
  
  
  
