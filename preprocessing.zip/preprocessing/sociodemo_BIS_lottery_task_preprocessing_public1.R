#Clear existing data and graphics
rm(list=ls())
graphics.off()
#Load Hmisc library
library(Hmisc)
#Read Data
setwd("")
data=read.csv('sociodemo_gaming_pilot2.csv', sep = ";")
#Setting Factors(will create new variable for factors)
data$sex = factor(data$sex,levels=c("1","2","3","4"))
data$a_levels = factor(data$a_levels,levels=c("1","2"))
data$gaming = factor(data$gaming,levels=c("1","2","3","4","5"))
names(data)[names(data) == 'record_id'] <- 'participant_ID'


#set path for saving long dataset
savedir = ("")

#csv
path_C <- paste0(savedir, "/B3_SAT_sociodemo_BIS_lottery_task_public1.csv", sep="")
write.csv(data, file=path_C, row.names=F)

