#Clear existing data and graphics
rm(list=ls())
graphics.off()
#Load Hmisc library
library(Hmisc)
#Read Data
setwd("")
data=read.csv('sociodemo_gaming_BIS_lottery_pilot3.csv', sep = ";")
#compute score for lottery task
for(f in (1:nrow(data))){
data$lottery_sum_optionB[f] = sum(
                         data$lottery1[f],
                         data$lottery2[f],
                         data$lottery3[f],
                         data$lottery4[f],
                         data$lottery5[f],
                         data$lottery6[f],
                         data$lottery7[f],
                         data$lottery8[f],
                         data$lottery9[f],
                         data$lottery10[f]
                         )}


#Setting Factors(will create new variable for factors)
#levels (from 1 to 4) --> "male","female","intersex / diverse","prefer not to disclose"
data$sex = factor(data$sex,levels=c("1","2","3","4"))
#levels --> 1 = Yes, 2 = No
data$a_levels = factor(data$a_levels,levels=c("1","2"))
#levels (from 1 to 5)-->"(Almost) never","Less than once a month","Once or several times a month","Once or several times a week","(Almost) daily")
data$gaming = factor(data$gaming,levels=c("1","2","3","4","5"))
#lottery --> 0 = Option A, 1 = Option B
data$lottery1 = factor(data$lottery1,levels=c("0","1"))
data$lottery2 = factor(data$lottery2,levels=c("0","1"))
data$lottery3 = factor(data$lottery3,levels=c("0","1"))
data$lottery4 = factor(data$lottery4,levels=c("0","1"))
data$lottery5 = factor(data$lottery5,levels=c("0","1"))
data$lottery6 = factor(data$lottery6,levels=c("0","1"))
data$lottery7 = factor(data$lottery7,levels=c("0","1"))
data$lottery8 = factor(data$lottery8,levels=c("0","1"))
data$lottery9 = factor(data$lottery9,levels=c("0","1"))
data$lottery10 = factor(data$lottery10,levels=c("0","1"))

names(data)[names(data) == 'record_id'] <- 'participant_ID'

#set path for saving long dataset
savedir = ("")

#csv
path_C <- paste0(savedir, "/B3_SAT_sociodemo_BIS_lottery_task_public2.csv", sep="")
write.csv(data, file=path_C, row.names=F)

