#by Sophia-Helen Sass
# preprocess debriefing data 

#clear workspace
rm(list = ls())

#put packages in library
library(rjson)
library(plyr)
library(dplyr)

#set paths for data from SAT UP 
setwd("")
datadir = ("")

#prepare loop through folders
folders = dir(datadir) 
nid = max(c(length(folders)))

#prepare empty table to be filled with summarize participant data within the loop
# Set up an empty list to store individual data frames
df_list <- list()

# Start loop for pre-processing of all data sets
for (i in 1:nid) {
  tryCatch({
    subj    = folders[i]
    txtpath = paste0(datadir, "/", subj, sep="")
    setwd(txtpath)
    
    # Data extraction from json-files starts here  
    file_raw <- fromJSON(file = "SAT_debriefing.json", method = "C", unexpected.escape = "error", simplify = TRUE)
    
    # Create a data frame for the current participant
    df_participant <- data.frame(
      move_key = file_raw[["move_key"]],
      jump_key = file_raw[["jump_key"]],
      planet_value_minus20 = file_raw[["planet_value_minus20"]],
      planet_value_minus10 = file_raw[["planet_value_minus10"]],
      planet_value_0 = file_raw[["planet_value_0"]],
      planet_value_plus10 = file_raw[["planet_value_plus10"]],
      planet_value_plus20 = file_raw[["planet_value_plus20"]],
      prob_target_miss = file_raw[["prob_target_miss"]],
      steps_planned = file_raw[["steps_planned"]],
      risk_taking = file_raw[["risk_taking"]],
      participant_ID = subj
    )
    
    # Append the data frame to the list
    df_list[[i]] <- df_participant
    
    # Report subjects with problems reading the log file
  }, error = function(e) {
    message("A problem occurred - please check subject folder: ", folders[i])
  })
  
  # Set working directory back to the main data directory
  setwd(datadir)
}

# Combine all individual data frames into one final data frame
df_SAT <- bind_rows(df_list)

#rename factor levels for risk taking behavior 
df_SAT$risk_taking <- factor(df_SAT$risk_taking, levels = 1:4, labels = c("risky", "cautious", "neither", "noidea"))


#set path for saving data set as csv
savedir = ("")
path_C <- paste0(savedir, "/B3_SAT_debriefing_public.csv", sep="")
write.csv(df_SAT, file=path_C, row.names=F)


