# by Sophia-Helen Sass (2025)
# read in all data (raw behavioral and inference, debriefing, and questionnaires) ####

# preparation ####
# clear workspace
rm(list = ls())

# load packages
library(plyr)
library(tidyr)
library(dplyr)
library(reshape)
library(rstatix)

# load and format task data ####
# probabilistic planning task and related data
# import inference data from all models

# import planning task data
setwd("")

SAT_behavioral_data=read.csv('B3_SAT_144trials_public.csv')

# import inferred parameter data
SAT_params=read.csv('SAT_UP_params_public.csv')
SAT_params$subject<-rm()

# import SAT debriefing
setwd("")
SAT_DB=read.csv('B3_SAT_debriefing_public.csv')

# questionnaires
setwd("")
sociodemo_BIS_lottery_task1=read.csv('B3_SAT_sociodemo_BIS_lottery_task_public1.csv')
sociodemo_BIS_lottery_task2=read.csv('B3_SAT_sociodemo_BIS_lottery_task_public2.csv')

# Identify the columns in each data frame
cols_quest1 <- colnames(sociodemo_BIS_lottery_task1)
cols_quest2 <- colnames(sociodemo_BIS_lottery_task2)

# Ensure both data frames have the same columns
common_cols <- union(cols_quest1, cols_quest2)

# Add missing columns with NA in both data frames
sociodemo_BIS_lottery_task1[setdiff(common_cols, cols_quest1)] <- NA
sociodemo_BIS_lottery_task2[setdiff(common_cols, cols_quest2)] <- NA

# row bind both data frames
quest<-rbind(sociodemo_BIS_lottery_task1,sociodemo_BIS_lottery_task2)

# merge all data by Participants_ID to get one big data frame #####
SAT_all_vars <- merge(SAT_behavioral_data,SAT_DB,           by = 'participant_ID')
SAT_all_vars <- merge(SAT_all_vars,SAT_params,            by = 'participant_ID', all=TRUE)
SAT_all_vars <- merge(SAT_all_vars,quest,            by = 'participant_ID',all=TRUE)

# throw out all variables that do not have any entries 
SAT_all_vars <- subset(SAT_all_vars,!is.na(gain_total))

# saving the data as csv ####
savedir = ("")
path_C <- paste0(savedir, "/SATUP_sociodemo_quest_all_data_144trials_public",".csv", sep="")
write.csv(SAT_all_vars, file=path_C, row.names=F)

