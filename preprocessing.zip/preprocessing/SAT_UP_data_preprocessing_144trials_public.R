# by Sophia-Helen Sass (2025)
# preprocess raw behavioral data from Space Adventure Task - Uncertain Planet (SAT UP) 

# clear workspace
rm(list = ls())

# prepare workspace and data ####
# load packages
library(rjson)
library(plyr)
library(dplyr)

#load planet configs and trial info 
setwd("")
planets = read.csv('config_file_main.csv')
#add column for trial number
planets$trial <- c(1:144)

#set paths for raw behavioral data
datadir = ("")

#load Planning Depth data 
PD = read.csv('')
PD$condition <- NULL # delete this column because otherwise conflict later when we concatenate dfs

# load random agent and exhaustive planning agent data to compute relative performance
random_agent = read.csv('miniblock_gain_mean_std_rational_1000.csv')
random_agent <- random_agent[ ,-c(4:7)]
names(random_agent)[names(random_agent) == 'Mean_gain_PD3'] <- 'Gain'
random_agent$condition<-planets$condition
random_agent$trial<-c(1:144)

# exhaustive planning agent (here called "rational")
rational_agent = read.csv('miniblock_gain_mean_std_rational_1000.csv')
rational_agent <- rational_agent[ ,-c(4:7)]
names(rational_agent)[names(rational_agent) == 'Mean_gain_PD3'] <- 'Gain'
rational_agent$condition<-planets$condition
rational_agent$trial<-c(1:144)

# this is how many points gets an agent gets per mini-block summed up
random_agentgaintest<- sum(random_agent$Gain[random_agent$condition == "1"])
random_agentgaincontrol<- sum(random_agent$Gain[random_agent$condition == "0"])
random_agentgainsum <- sum(random_agent$Gain)

random_agentgainmeantest<-mean(random_agent$Gain[random_agent$condition == "1"])
random_agentgainmeancontrol<-mean(random_agent$Gain[random_agent$condition == "0"])
random_agentgainmeansum<-mean(random_agent$Gain)

# fetching raw behavioral  data from folders ####
# structure: one folder per participant contains json-data files of SAT UP
# Algorithm goes through all participant folders to fetch respective json-files, 
# pre-process them to summarized data for each participant and concatenate them to a new data frame
# at the end, a new data set is saved and ready to be analyzed further.

#prepare loop through folders
folders = dir(datadir) 
nid = max(c(length(folders)))

#prepare empty table to be filled with summarize participant data within the loop
SAT = array(NA, c(nid,111)) 

#start loop for pre-processing of all data sets
for (i in 1:nid){ 
  tryCatch({
    subj    = folders[i]
    txtpath = paste0(datadir, "/", subj, sep="")
    setwd(txtpath)
    
    #data extraction from json-files starts here  
    file_raw <- fromJSON(file = "SAT_pruning.json", method = "C", unexpected.escape = "error", simplify = T)
    
    #create empty array to write in
    data = array(NA, c(144,15)) 
    
    # read out relevant measures from log file ####
    ## game points (performance) ####
    # starting points mini-block (= points after action 3 of the mini-block before)
    for (f in 1:144){ 
      data[f,1] <- file_raw[["points"]][[f]][1]}
    #points after action 1
    for (f in 1:144){ 
      data[f,2] <- file_raw[["points"]][[f]][2]}
    #points after action 2
    for (f in 1:144){ 
      data[f,3] <- file_raw[["points"]][[f]][3]}
    
    ## Response times (RT) ####
    # from stimulus onset to button press 
    # RT action 1
    for (f in 1:144){ 
      data[f,4] <- file_raw[["responses"]][["RT"]][[f]][1]}
    # RT action 2
    for (f in 1:144){ 
      data[f,5] <- file_raw[["responses"]][["RT"]][[f]][2]-
        file_raw[["responses"]][["RT"]][[f]][1]}
    # RT action 3
    for (f in 1:144){ 
      data[f,6] <- file_raw[["responses"]][["RT"]][[f]][3]-
        file_raw[["responses"]][["RT"]][[f]][2]}
    
    # action choices (1 step or 2 steps)
    # action 1
    for (f in 1:144){ 
      data[f,7] <- file_raw[["responses"]][["actions"]][[f]][1]}
    # action 2
    for (f in 1:144){ 
      data[f,8] <- file_raw[["responses"]][["actions"]][[f]][2]}
    # action 3
    for (f in 1:144){ 
      data[f,9] <- file_raw[["responses"]][["actions"]][[f]][3]}
    
    
    ## outcome states (1,2,3,4,5 or 6) ####
    # outcome state 1
    for (f in 1:144){ 
      data[f,10] <-file_raw[["states"]][[f]][2]}
    # outcome state 2
    for (f in 1:144){ 
      data[f,11] <-file_raw[["states"]][[f]][3]}
    # outcome state 3
    for (f in 1:144){ 
      data[f,12] <-file_raw[["states"]][[f]][4]}
    
    
    ## low probability transitions ####
    # (called "failed" or "missed" transitions)
    # Keep only logical entries in mainPlanetMissedArray
    file_raw[["mainPlanetMissedArray"]] <- file_raw[["mainPlanetMissedArray"]][sapply(file_raw[["mainPlanetMissedArray"]], is.logical)]
    
    # transition1
    for (f in 1:144){
      data[f,13]<-as.character(file_raw[["mainPlanetMissedArray"]][[f]][1])}
    # transition2
    for (f in 1:144){ 
      data[f,14] <- as.character(file_raw[["mainPlanetMissedArray"]][[f]][2])}
    # transition3
    for (f in 1:144){ 
      data[f,15] <- as.character(file_raw[["mainPlanetMissedArray"]][[f]][3])}
    
    ## create data frame for relevant measures of each trial for respective participant ####
    dimnames(data) = list(1:144,c(
      "points_action1",
      "points_action2",
      "points_action3",
      "RT1",
      "RT2",
      "RT3",
      "action1",
      "action2",
      "action3",
      "outcome_state1",
      "outcome_state2",
      "outcome_state3",
      "transition1fail",
      "transition2fail",
      "transition3fail"
    ))
    
    # convert to data frame
    df_SAT <- data.frame(data)
    # enter ascending trial number
    df_SAT$trial <- c(1:144)
    # merge trial info and participant data frame 
    df_SAT <- merge(df_SAT,planets,by = 'trial')
    
    ## uncertain planet distance info ####
    for (f in 1:nrow(df_SAT)){
      if(df_SAT$start_pos[f]+1==df_SAT$uncertain_planet[f] |
         (df_SAT$start_pos[f]==6 & df_SAT$uncertain_planet[f]==1) 
      ){ 
        df_SAT$UP_distance[f]<-"1"}
      else if (df_SAT$start_pos[f]+2==df_SAT$uncertain_planet[f]|
                 df_SAT$start_pos[f]==6 & df_SAT$uncertain_planet[f]==2|
                 df_SAT$start_pos[f]==5 & df_SAT$uncertain_planet[f]==1
      ){ 
        df_SAT$UP_distance[f]<- "2"}
      else if (df_SAT$start_pos[f]+3==df_SAT$uncertain_planet[f]|
                 df_SAT$start_pos[f]==6 & df_SAT$uncertain_planet[f]==3|
                 df_SAT$start_pos[f]==5 & df_SAT$uncertain_planet[f]==2|
                 df_SAT$start_pos[f]==4 & df_SAT$uncertain_planet[f]==1
  ){
    df_SAT$UP_distance[f]<-"3"}
      else if (df_SAT$start_pos[f]+4==df_SAT$uncertain_planet[f]|
                 df_SAT$start_pos[f]==6 & df_SAT$uncertain_planet[f]==4|
                 df_SAT$start_pos[f]==5 & df_SAT$uncertain_planet[f]==3|
                 df_SAT$start_pos[f]==4 & df_SAT$uncertain_planet[f]==2|
                 df_SAT$start_pos[f]==3 & df_SAT$uncertain_planet[f]==1
      ){
        df_SAT$UP_distance[f]<-"4"}
      else {
        df_SAT$UP_distance[f]<-"5"}
    }
    
    df_SAT$UP_distance <- as.factor(df_SAT$UP_distance)
    
    
    # # enter ascending new trial number
    # df_SAT$trial <- c(1:c(nrow(df_SAT)))
    
    # make sure that your data has the correct format (numeric and characters)
    # make some numeric
    df_SAT[ ,c(1:13)] <- lapply(df_SAT[ c(1:13)], as.numeric)
    # make some factors
    df_SAT$condition <- as.factor(df_SAT$condition)
    df_SAT$UP_distance <- as.factor(df_SAT$UP_distance)
    
    ## points per mini-block ####
    for (f in 1:nrow(df_SAT)){
      df_SAT[f+1,47]  <- df_SAT$points_action3[f+1]-df_SAT$points_action3[f]}
    names(df_SAT)[names(df_SAT)=='V47'] <- 'points_gained'
    df_SAT$points_gained[1] <- df_SAT$points_action3[1]-350
    df_SAT <- df_SAT[1:(nrow(df_SAT)-1), ] 
   
    ## optimal sequence executed, when no low-probability transition occurred ####
    # optimal = highest expected reward
    for (f in 1:nrow(df_SAT)){
      df_SAT[f,48] <- df_SAT$action1[f] == df_SAT$action1_rational_PD3[f] &
        df_SAT$action2[f] == df_SAT$action2_rational_PD3[f] &
        df_SAT$action3[f] == df_SAT$action3_rational_PD3[f]&
        df_SAT$transition1fail[f] == FALSE & 
        df_SAT$transition2fail[f] == FALSE & 
        df_SAT$transition3fail[f] == FALSE}
    names(df_SAT)[names(df_SAT) == 'V48'] <- 'optimal_seq_exe'
    
    # first action optimal but low-probability transition afterwards
    for (f in 1:nrow(df_SAT)){
      df_SAT[f,49] <- df_SAT$action1[f] == df_SAT$action1_rational_PD3[f]&
        df_SAT$transition1fail[f] == TRUE}
    names(df_SAT)[names(df_SAT) == 'V49'] <- 'optimal_1st_action_transfail'
    
    # first and second action correct but low-probability transition afterwards
    for (f in 1:nrow(df_SAT)){
      df_SAT[f,50] <- df_SAT$action1[f] == df_SAT$action1_rational_PD3[f]&
        df_SAT$transition1fail[f] == FALSE &
        df_SAT$action2[f] == df_SAT$action2_rational_PD3[f]&
        df_SAT$transition2fail[f] == TRUE}
    names(df_SAT)[names(df_SAT) == 'V50'] <- 'optimal_1st_2nd_action_transfail'
    
    # likely optimal action sequence chosen but low-probability transition occurred
    for (f in 1:nrow(df_SAT)){
      df_SAT[f,51] <- df_SAT$optimal_1st_2nd_action_transfail[f] == TRUE |
        df_SAT$optimal_1st_action_transfail[f] == TRUE}
    names(df_SAT)[names(df_SAT) == 'V51'] <- 'optimal_but_transfail'
  
    
    ## expected points in percent (%) of optimal expected reward ####
    for (f in 1:nrow(df_SAT)){
      df_SAT[f,52] <- df_SAT$points_gained[f] / df_SAT$expected_points_rational_PD3[f]*100}
    names(df_SAT)[names(df_SAT) == 'V52'] <- 'percent_gained_expected_points'
    
    ## difference between earned and expected points ####
    for (f in 1:nrow(df_SAT)){
      df_SAT[f,53] <- df_SAT$points_gained[f] - df_SAT$expected_points_rational_PD3[f]}
    names(df_SAT)[names(df_SAT) == 'V53'] <- 'diff_gained_expected_points'
    
    ## uncertain planet chosen in action sequence ####
    for (f in 1:nrow(df_SAT)){
      if(df_SAT$UP_distance[f]==1 & df_SAT$action1[f]==1|
         df_SAT$UP_distance[f]==2 & df_SAT$action1[f]==2|
         df_SAT$UP_distance[f]==2 & df_SAT$action1[f]==1 & df_SAT$action2[f]==1 |
         df_SAT$UP_distance[f]==3 & df_SAT$action1[f]==2 & df_SAT$action2[f]==1 |
         df_SAT$UP_distance[f]==3 & df_SAT$action1[f]==1 & df_SAT$action2[f]==2 |
         df_SAT$UP_distance[f]==3 & df_SAT$action1[f]==1 & df_SAT$action2[f]==1 & df_SAT$action3[f]==1|
         
         df_SAT$UP_distance[f]==4 & df_SAT$action1[f]==2 & df_SAT$action2[f]==2 |
         df_SAT$UP_distance[f]==4 & df_SAT$action1[f]==2 & df_SAT$action2[f]==1 & df_SAT$action3[f]==1 |
         df_SAT$UP_distance[f]==4 & df_SAT$action1[f]==1 & df_SAT$action2[f]==1 & df_SAT$action3[f]==2 |
         df_SAT$UP_distance[f]==4 & df_SAT$action1[f]==1 & df_SAT$action2[f]==2 & df_SAT$action3[f]==1 |
         
         df_SAT$UP_distance[f]==5 & df_SAT$action1[f]==2 & df_SAT$action2[f]==2 & df_SAT$action3[f]==1| 
         df_SAT$UP_distance[f]==5 & df_SAT$action1[f]==2 & df_SAT$action2[f]==1 & df_SAT$action3[f]==2|
         df_SAT$UP_distance[f]==5 & df_SAT$action1[f]==1 & df_SAT$action2[f]==2 & df_SAT$action3[f]==2
      ){
        df_SAT[f,54] <- TRUE}
      else {
        df_SAT[f,54]<-FALSE}
    }
    names(df_SAT)[names(df_SAT) == 'V54'] <- 'uncertain_planet_chosen'
    
    # check for uncertain planet high-probability transition 
    for (f in 1:nrow(df_SAT)){
      if(df_SAT$uncertain_planet_chosen[f]==T & df_SAT$transition1fail[f]==F
         & df_SAT$transition2fail[f]==F & df_SAT$transition3fail[f]==F
        ){
        df_SAT[f,55] <- TRUE}
      else if(df_SAT$uncertain_planet_chosen[f]==T & df_SAT$transition1fail[f]==T|
              df_SAT$uncertain_planet_chosen[f]==T & df_SAT$transition2fail[f]==T|
              df_SAT$uncertain_planet_chosen[f]==T & df_SAT$transition3fail[f]==T
              ){
        df_SAT[f,55] <- FALSE}
      else {
        df_SAT[f,55]<-"UP not chosen"}
    }
    names(df_SAT)[names(df_SAT) == 'V55'] <- 'uncertain_planet_transsuccess'
    
    
    
    ## uncertain planet low-probability transition with replanning ####
    for (f in 1:nrow(df_SAT)){
      if(df_SAT$UP_distance[f]==1 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$outcome_state1[f]==df_SAT$uncertain_planet[f]-1|
         
         df_SAT$UP_distance[f]==1 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$uncertain_planet[f]==1 & 
         df_SAT$outcome_state1[f]==6|
         
         df_SAT$UP_distance[f]==2 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==2 & 
         df_SAT$outcome_state1[f]== df_SAT$uncertain_planet[f]+1|
         
         df_SAT$UP_distance[f]==2 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==2 & 
         df_SAT$uncertain_planet[f]==6 & 
         df_SAT$outcome_state1[f]==1|
         
         df_SAT$UP_distance[f]==2 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==1 & 
         df_SAT$action2[f]==1 & 
         df_SAT$outcome_state2[f]== df_SAT$uncertain_planet[f]-1|
         
         df_SAT$UP_distance[f]==2 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==1 & 
         df_SAT$action2[f]==1 & 
         df_SAT$uncertain_planet[f]==1 &
         df_SAT$outcome_state2[f]==6|
         
         df_SAT$UP_distance[f]==3 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==2 & 
         df_SAT$action2[f]==1 & 
         df_SAT$outcome_state2[f]== df_SAT$uncertain_planet[f]-1|
         
         df_SAT$UP_distance[f]==3 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==2 & 
         df_SAT$action2[f]==1 & 
         df_SAT$uncertain_planet[f]==1 & 
         df_SAT$outcome_state2[f]==6|
         
         df_SAT$UP_distance[f]==3 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==1 & 
         df_SAT$action2[f]==2 & 
         df_SAT$outcome_state2[f]== df_SAT$uncertain_planet[f]+1|
         
         df_SAT$UP_distance[f]==3 &
         df_SAT$uncertain_planet_transsuccess[f]==F &
         df_SAT$action1[f]==1 &
         df_SAT$action2[f]==2 &
         df_SAT$uncertain_planet[f]==6 &
         df_SAT$outcome_state2[f]==1|
         
         df_SAT$UP_distance[f]==4 &
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==2 & 
         df_SAT$action2[f]==2 & 
         df_SAT$outcome_state2[f]== df_SAT$uncertain_planet[f]+1|
         
         df_SAT$UP_distance[f]==4 & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$action1[f]==2 & 
         df_SAT$action2[f]==2 & 
         df_SAT$uncertain_planet[f]==6 & 
         df_SAT$outcome_state2[f]==1|
         
         df_SAT$UP_distance[f]==4 & 
         df_SAT$uncertain_planet_transsuccess[f]==F &
         df_SAT$action1[f]==2 & 
         df_SAT$action2[f]==2 & 
         df_SAT$uncertain_planet[f]==6 & df_SAT$outcome_state2[f]==1
      ){
        df_SAT[f,56] <- TRUE}
      else {
        df_SAT[f,56]<-FALSE}
    }
    names(df_SAT)[names(df_SAT) == 'V56'] <- 'uncertain_planet_transfail_replan'
    
    
    ## uncertain planet low-probability transition last action (no replanning) ####
    for (f in 1:nrow(df_SAT)){
      if( df_SAT$UP_distance[f]==4 &
        df_SAT$uncertain_planet_transsuccess[f]==F &
        df_SAT$action1[f]==2 &
        df_SAT$action2[f]==1 &
        df_SAT$action3[f]==1 &
        df_SAT$outcome_state3[f]== df_SAT$uncertain_planet[f]-1|
        
        df_SAT$UP_distance[f]==4 &
        df_SAT$uncertain_planet_transsuccess[f]==F &
        df_SAT$action1[f]==1 &
        df_SAT$action2[f]==2 &
        df_SAT$action3[f]==1 &
        df_SAT$outcome_state3[f]== df_SAT$uncertain_planet[f]-1|
        
        df_SAT$UP_distance[f]==4 &
        df_SAT$uncertain_planet_transsuccess[f]==F &
        df_SAT$action1[f]==1 &
        df_SAT$action2[f]==1 &
        df_SAT$action3[f]==2 &
        df_SAT$outcome_state3[f]== df_SAT$uncertain_planet[f]+1|
        
        df_SAT$UP_distance[f]==4 &
        df_SAT$uncertain_planet_transsuccess[f]==F &
        df_SAT$action1[f]==2 &
        df_SAT$action2[f]==1 &
        df_SAT$action3[f]==1 &
        df_SAT$outcome_state3[f]== df_SAT$uncertain_planet[f]-1|

        df_SAT$UP_distance[f]==4 &
        df_SAT$uncertain_planet_transsuccess[f]==F &
        df_SAT$action1[f]==1 &
        df_SAT$action2[f]==2 &
        df_SAT$action3[f]==1 &
        df_SAT$outcome_state3[f]== df_SAT$uncertain_planet[f]-1|

        df_SAT$UP_distance[f]==4 &
        df_SAT$uncertain_planet_transsuccess[f]==F &
        df_SAT$action1[f]==1 &
        df_SAT$action2[f]==1 &
        df_SAT$action3[f]==2 &
        df_SAT$outcome_state3[f]== df_SAT$uncertain_planet[f]+1|
        
        df_SAT$UP_distance[f]==5
        ){
        df_SAT[f,57] <- TRUE}
      else {
        df_SAT[f,57]<-FALSE}
    }
    names(df_SAT)[names(df_SAT) == 'V57'] <- 'uncertain_planet_last_action'
    
    
    
    ## uncertain planet low-probability transition without replanning ####
    for (f in 1:nrow(df_SAT)){
      if(df_SAT$uncertain_planet_chosen[f]==T & 
         df_SAT$uncertain_planet_transsuccess[f]==F & 
         df_SAT$uncertain_planet_transfail_replan[f]==F &
         df_SAT$uncertain_planet_last_action[f]==F
       ){
        df_SAT[f,58] <- TRUE}
      else {
        df_SAT[f,58]<-FALSE}
    }
    names(df_SAT)[names(df_SAT) == 'V58'] <- 'uncertain_planet_transfail_noreplan'
    
    df_SAT$participant_ID <- subj
    df_SAT$subject <- i
    
    ## concatenate with inferred planning depth data ####
    PD_subject <- subset(PD, subject==i)
    df_SAT <- merge(df_SAT, PD_subject, by = c("trial", "subject"), all.x = TRUE)
    
    # order the merged data frame by subject and then trial
    df_SAT <- df_SAT[order(df_SAT$subject, df_SAT$trial), ] 
    
    # trial exclusion #####
    # calculate upper quantile for RTs (95. percentile)
    upper_quantile_RT1 <- quantile(df_SAT$RT1, 0.99, na.rm = TRUE)
    upper_quantile_RT2 <- quantile(df_SAT$RT2, 0.99, na.rm = TRUE)
    upper_quantile_RT3 <- quantile(df_SAT$RT2, 0.99, na.rm = TRUE)
    
    # Trials that will be excluded
    RT1outlier <- subset(df_SAT, RT1 < 150 | RT1 > upper_quantile_RT1)
    RT2outlier <- subset(df_SAT, RT2 > upper_quantile_RT2)
    RT3outlier <- subset(df_SAT, RT3 > upper_quantile_RT3)
    
    #  Exclude trials with RT < 150 ms or RT > upper quantile
    df_SAT <- subset(df_SAT, RT1 > 150 & RT1 <= upper_quantile_RT1)
    df_SAT <- subset(df_SAT, RT2 <= upper_quantile_RT2)
    df_SAT <- subset(df_SAT, RT3 <= upper_quantile_RT3)
    
    # save long data as csv for respective participant in loop ####
    # set path for saving long dataset
    # savedir = ("P:/037/B3_MAIN_STUDY/02_Piloting/pilot_3/data/preprocessed/144trials")
    savedir = ("//Volumes/nic_projects/037/B3_MAIN_STUDY/02_Piloting/pilot_3/data/preprocessed/144trials")
    path_C <- paste0(savedir, "/B3_SAT_long_144trials_public",subj,".csv", sep="")
    write.csv(df_SAT, file=path_C, row.names=F)
    
    # preprocess data on participant-level: create summarized measures for each participant ####
    # responses split by optimality (action sequence with highest expected reward chosen)
    optimal <- subset(df_SAT, optimal_seq_exe == TRUE| optimal_but_transfail == TRUE)

    # subset trials of different conditions
    UP1 <- subset(df_SAT, UP_distance == 1)
    UP2 <- subset(df_SAT, UP_distance == 2)
    UP1_2 <- subset(df_SAT, UP_distance == 1 | UP_distance == 2)
    UP3 <- subset(df_SAT, UP_distance == 3)
    UP4 <- subset(df_SAT, UP_distance == 4)
    UP3_4 <- subset(df_SAT, UP_distance == 3 | UP_distance == 4)
    UP5 <- subset(df_SAT, UP_distance == 5)

    
    UP1_replan <- subset(UP1,uncertain_planet_transfail_replan ==T)
    UP1_noreplan <- subset(UP1,uncertain_planet_transfail_noreplan ==T & uncertain_planet_last_action ==F)
    UP1_transsuccess <- subset(UP1,uncertain_planet_transsuccess ==T)
    UP1_transfail <- subset(UP1,uncertain_planet_transfail_noreplan ==T | uncertain_planet_transfail_replan ==T)
    
    UP2_replan <- subset(UP2,uncertain_planet_transfail_replan ==T)
    UP2_noreplan <- subset(UP2,uncertain_planet_transfail_noreplan ==T & uncertain_planet_last_action==F)
    UP2_transsuccess <- subset(UP2,uncertain_planet_transsuccess ==T)
    UP2_transfail <- subset(UP2,uncertain_planet_transfail_noreplan ==T | uncertain_planet_transfail_replan ==T)
    
    UP3_replan<- subset(UP3,uncertain_planet_transfail_replan ==T)
    UP3_noreplan <- subset(UP3,uncertain_planet_transfail_noreplan ==T & uncertain_planet_last_action==F)
    UP3_transsuccess <- subset(UP3,uncertain_planet_transsuccess ==T)
    UP3_transfail <- subset(UP3,uncertain_planet_transfail_noreplan ==T | uncertain_planet_transfail_replan ==T)
    
    UP4_replan <- subset(UP4,uncertain_planet_transfail_replan ==T)
    UP4_noreplan <- subset(UP4,uncertain_planet_transfail_noreplan ==T & uncertain_planet_last_action==F)
    UP4_transsuccess <- subset(UP4,uncertain_planet_transsuccess ==T)
    UP4_transfail <- subset(UP4,uncertain_planet_transfail_noreplan ==T | uncertain_planet_transfail_replan ==T)
    
    UP5_replan <- subset(UP5,uncertain_planet_transfail_replan ==T)
    UP5_noreplan <- subset(UP5,uncertain_planet_transfail_noreplan ==T & uncertain_planet_last_action==F)
    UP5_transsuccess <- subset(UP5,uncertain_planet_transsuccess ==T)
    

    # fill new data frame with one value per variable per participant
    # subject ID
    SAT[i,1]  = subj
    
    # total number of responses
    SAT[i,2]  = nrow(df_SAT)
    
    ## performance ####
    # absolute amount of points
    # gained in total
    SAT[i,3] = sum(df_SAT$points_gained,na.rm=T)
    
    # relative amount of points (%)
    # calculate new gain scale between exhaustive planning and random
    SAT[i,4] = (sum(df_SAT$points_gained,na.rm=T) - random_agentgainsum)/
      (sum(df_SAT$expected_points_rational_PD3,na.rm=T)-random_agentgainsum)*100
    
    # compute random and rational agent's performances per mini-block type
    random_agent_UP1 <- random_agent[random_agent$trial %in% 
                                       df_SAT$trial[df_SAT$UP_distance == 1], ]
    random_agent_UP1_sum <- sum (random_agent_UP1$Gain)
    
    rational_agent_UP1 <- rational_agent[rational_agent$trial %in% 
                                       df_SAT$trial[df_SAT$UP_distance == 1], ]
    rational_agent_UP1_sum <- sum (rational_agent_UP1$Gain)
    
    random_agent_UP2 <- random_agent[random_agent$trial %in% 
                                       df_SAT$trial[df_SAT$UP_distance == 2], ]
    random_agent_UP2_sum <- sum (random_agent_UP2$Gain)
    
    rational_agent_UP2 <- rational_agent[rational_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 2], ]
    rational_agent_UP2_sum <- sum(rational_agent_UP2$Gain)
    
    random_agent_UP3 <- random_agent[random_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 3], ]
    random_agent_UP3_sum <- sum (random_agent_UP3$Gain)
    
    rational_agent_UP3 <- rational_agent[rational_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 3], ]
    rational_agent_UP3_sum <- sum (rational_agent_UP3$Gain)
    
    random_agent_UP4 <- random_agent[random_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 4], ]
    random_agent_UP4_sum <- sum (random_agent_UP4$Gain)
    
    rational_agent_UP4 <- rational_agent[rational_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 4], ]
    rational_agent_UP4_sum <- sum (rational_agent_UP4$Gain)
    
    random_agent_UP5 <- random_agent[random_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 5], ]
    random_agent_UP5_sum <- sum (random_agent_UP5$Gain)
    
    rational_agent_UP5 <- rational_agent[rational_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 5], ]
    rational_agent_UP5_sum <- sum (rational_agent_UP5$Gain)
    
    
    # compute relative performance per mini-block type
    SAT[i,5] = (sum(df_SAT$points_gained[df_SAT$UP_distance=="1"],na.rm=T) - random_agent_UP1_sum)/
      (rational_agent_UP1_sum-random_agent_UP1_sum)*100
    
    SAT[i,6] = (sum(df_SAT$points_gained[df_SAT$UP_distance=="2"],na.rm=T) - random_agent_UP2_sum)/
      (rational_agent_UP2_sum-random_agent_UP2_sum)*100
    
    SAT[i,7] = (sum(df_SAT$points_gained[df_SAT$UP_distance=="3"],na.rm=T) - random_agent_UP3_sum)/
      (rational_agent_UP3_sum-random_agent_UP3_sum)*100
    
    SAT[i,8] = (sum(df_SAT$points_gained[df_SAT$UP_distance=="4"],na.rm=T) - random_agent_UP4_sum)/
      (rational_agent_UP4_sum-random_agent_UP4_sum)*100
    
    SAT[i,9] = (sum(df_SAT$points_gained[df_SAT$UP_distance=="5"],na.rm=T) - random_agent_UP5_sum)/
      (rational_agent_UP5_sum-random_agent_UP5_sum)*100
    
    # relative performance for mini-block types with equal amount of re-planning costs
    random_agent_UP1_2 <- random_agent[random_agent$trial %in% 
                                         df_SAT$trial[df_SAT$UP_distance == 1 | 
                                         df_SAT$UP_distance == 2], ]
    random_agent_UP1_2_sum <- sum (random_agent_UP1_2$Gain)
    
    rational_agent_UP1_2 <- rational_agent[rational_agent$trial %in% 
                                          df_SAT$trial[df_SAT$UP_distance == 1 | 
                                          df_SAT$UP_distance == 2], ]
    rational_agent_UP1_2_sum <- sum (rational_agent_UP1_2$Gain)
    
    SAT[i,10] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(1, 2)], na.rm = T) - random_agent_UP1_2_sum) /
                (rational_agent_UP1_2_sum - random_agent_UP1_2_sum) * 100
    
    
    random_agent_UP3_4 <- random_agent[random_agent$trial %in% 
                                           df_SAT$trial[df_SAT$UP_distance == 3 | 
                                           df_SAT$UP_distance == 4], ]
    random_agent_UP3_4_sum <- sum (random_agent_UP3_4$Gain)
    
    rational_agent_UP3_4 <- rational_agent[rational_agent$trial %in% 
                                           df_SAT$trial[df_SAT$UP_distance == 3 | 
                                           df_SAT$UP_distance == 4], ]
    rational_agent_UP3_4_sum <- sum (rational_agent_UP3_4$Gain)
    
    SAT[i,11] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(3, 4)], na.rm = T) - random_agent_UP3_4_sum) /
      (rational_agent_UP3_4_sum - random_agent_UP3_4_sum) * 100
    
    # relative performance overall when UP selected
    # overall
    random_agent_UPchosen<- random_agent[random_agent$trial %in% 
                                      df_SAT$trial[df_SAT$uncertain_planet_chosen == T], ]
    random_agent_UPchosen_sum <- sum (random_agent_UPchosen$Gain)
    
    rational_agent_UPchosen <- rational_agent[rational_agent$trial %in% 
                                      df_SAT$trial[df_SAT$uncertain_planet_chosen == T], ]
    rational_agent_UPchosen_sum <- sum (rational_agent_UPchosen$Gain)
    
    SAT[i,12] = (sum(df_SAT$points_gained[df_SAT$uncertain_planet_chosen == T],na.rm=T) - random_agent_UPchosen_sum)/
      (rational_agent_UPchosen_sum-random_agent_UPchosen_sum)*100
    
    # for mini-blocks with equal amount of re-planning costs
    random_agent_UP1_2_UPchosen <- random_agent[random_agent$trial %in% 
                                                  df_SAT$trial[df_SAT$UP_distance == 1 & 
                                                  df_SAT$uncertain_planet_chosen == T| 
                                                  df_SAT$UP_distance == 2 & 
                                                  df_SAT$uncertain_planet_chosen == T], ]
    random_agent_UP1_2_UPchosen_sum <- sum (random_agent_UP1_2_UPchosen$Gain)
    
    rational_agent_UP1_2_UPchosen<- rational_agent[rational_agent$trial %in%
                                                  df_SAT$trial[df_SAT$UP_distance == 1 & 
                                                  df_SAT$uncertain_planet_chosen == T|
                                                  df_SAT$UP_distance == 2 & 
                                                  df_SAT$uncertain_planet_chosen == T], ]
    rational_agent_UP1_2_UPchosen_sum <- sum (rational_agent_UP1_2_UPchosen$Gain)
    
    SAT[i,13] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(1, 2) & 
                 df_SAT$uncertain_planet_chosen == T], na.rm = T) - random_agent_UP1_2_UPchosen_sum) /
                (rational_agent_UP1_2_UPchosen_sum - random_agent_UP1_2_UPchosen_sum) * 100
    
    
    random_agent_UP3_4_UPchosen <- random_agent[random_agent$trial %in% 
                                                    df_SAT$trial[df_SAT$UP_distance == 3 & 
                                                    df_SAT$uncertain_planet_chosen == T | 
                                                    df_SAT$UP_distance == 4 & 
                                                    df_SAT$uncertain_planet_chosen == T], ]
    random_agent_UP3_4_UPchosen_sum <- sum (random_agent_UP3_4_UPchosen$Gain)
    
    rational_agent_UP3_4_UPchosen <- rational_agent[rational_agent$trial %in% 
                                                    df_SAT$trial[df_SAT$UP_distance == 3 & 
                                                    df_SAT$uncertain_planet_chosen == T | 
                                                    df_SAT$UP_distance == 4 & 
                                                    df_SAT$uncertain_planet_chosen == T], ]
    rational_agent_UP3_4_UPchosen_sum <- sum (rational_agent_UP3_4_UPchosen$Gain)
    
    SAT[i,14] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(3, 4)  & 
                 df_SAT$uncertain_planet_chosen == T], na.rm = T) - random_agent_UP3_4_UPchosen_sum) /
                (rational_agent_UP3_4_UPchosen_sum - random_agent_UP3_4_UPchosen_sum) * 100
    
    
    random_agent_UP5_UPchosen <- random_agent[random_agent$trial %in% 
                                                    df_SAT$trial[df_SAT$UP_distance == 5 & 
                                                    df_SAT$uncertain_planet_chosen == T], ]
    random_agent_UP5_UPchosen_sum <- sum (random_agent_UP5_UPchosen$Gain)
    
    rational_agent_UP5_UPchosen <- rational_agent[rational_agent$trial %in% 
                                                    df_SAT$trial[df_SAT$UP_distance == 5 & 
                                                    df_SAT$uncertain_planet_chosen == T], ]
    rational_agent_UP5_UPchosen_sum <- sum (rational_agent_UP5_UPchosen$Gain)
    
    SAT[i,15] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(5)  & 
                 df_SAT$uncertain_planet_chosen == T], na.rm = T) - random_agent_UP5_UPchosen_sum) /
                (rational_agent_UP5_UPchosen_sum - random_agent_UP5_UPchosen_sum) * 100
    
    
    
    # relative performance overall when UP NOT selected
    # overall
    random_agent_UPnotchosen<- random_agent[random_agent$trial %in% 
                                    df_SAT$trial[df_SAT$uncertain_planet_chosen == F], ]
    random_agent_UPnotchosen_sum <- sum (random_agent_UPnotchosen$Gain)
    
    rational_agent_UPnotchosen <- rational_agent[rational_agent$trial %in% 
                                     df_SAT$trial[df_SAT$uncertain_planet_chosen == F], ]
    rational_agent_UPnotchosen_sum <- sum (rational_agent_UPnotchosen$Gain)
    
    SAT[i,16] = (sum(df_SAT$points_gained[df_SAT$uncertain_planet_chosen == F],na.rm=T) - random_agent_UPnotchosen_sum)/
                (rational_agent_UPnotchosen_sum-random_agent_UPnotchosen_sum)*100
    
    # for mini-blocks with equal amount of re-planning costs
    random_agent_UP1_2_UPnotchosen <- random_agent[random_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 1 & 
                                        df_SAT$uncertain_planet_chosen == F| 
                                        df_SAT$UP_distance == 2 & 
                                        df_SAT$uncertain_planet_chosen == F], ]
    random_agent_UP1_2_UPnotchosen_sum <- sum (random_agent_UP1_2_UPnotchosen$Gain)
    
    rational_agent_UP1_2_UPnotchosen<- rational_agent[rational_agent$trial %in% 
                                        df_SAT$trial[df_SAT$UP_distance == 1 &         
                                        df_SAT$uncertain_planet_chosen == F|
                                        df_SAT$UP_distance == 2 & 
                                        df_SAT$uncertain_planet_chosen == F], ]
    rational_agent_UP1_2_UPnotchosen_sum <- sum (rational_agent_UP1_2_UPnotchosen$Gain)
    
    SAT[i,17] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(1, 2)  & 
                 df_SAT$uncertain_planet_chosen == F], na.rm = T) - random_agent_UP1_2_UPnotchosen_sum) /
                (rational_agent_UP1_2_UPnotchosen_sum - random_agent_UP1_2_UPnotchosen_sum) * 100
    
    
    random_agent_UP3_4_UPnotchosen <- random_agent[random_agent$trial %in% 
                                                     df_SAT$trial[df_SAT$UP_distance == 3 & 
                                                     df_SAT$uncertain_planet_chosen == F | 
                                                     df_SAT$UP_distance == 4 & 
                                                     df_SAT$uncertain_planet_chosen == F], ]
    random_agent_UP3_4_UPnotchosen_sum <- sum (random_agent_UP3_4_UPnotchosen$Gain)
    
    rational_agent_UP3_4_UPnotchosen <- rational_agent[rational_agent$trial %in% 
                                                     df_SAT$trial[df_SAT$UP_distance == 3 & 
                                                     df_SAT$uncertain_planet_chosen == F |
                                                     df_SAT$UP_distance == 4 & 
                                                     df_SAT$uncertain_planet_chosen == F], ]
    rational_agent_UP3_4_UPnotchosen_sum <- sum (rational_agent_UP3_4_UPnotchosen$Gain)
    
    SAT[i,18] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(3, 4)  & 
                 df_SAT$uncertain_planet_chosen == T], na.rm = T) - random_agent_UP3_4_UPnotchosen_sum) /
                (rational_agent_UP3_4_UPnotchosen_sum - random_agent_UP3_4_UPnotchosen_sum) * 100
    
    
    random_agent_UP5_UPnotchosen <- random_agent[random_agent$trial %in% 
                                                   df_SAT$trial[df_SAT$UP_distance == 5 & 
                                                   df_SAT$uncertain_planet_chosen == F], ]
    random_agent_UP5_UPnotchosen_sum <- sum (random_agent_UP5_UPnotchosen$Gain)
    
    rational_agent_UP5_UPnotchosen <- rational_agent[rational_agent$trial %in% 
                                                    df_SAT$trial[df_SAT$UP_distance == 5 & 
                                                    df_SAT$uncertain_planet_chosen == F], ]
    rational_agent_UP5_UPnotchosen_sum <- sum (rational_agent_UP5_UPnotchosen$Gain)
    
    SAT[i,19] = (sum(df_SAT$points_gained[df_SAT$UP_distance %in% c(5)  & 
                 df_SAT$uncertain_planet_chosen == T], na.rm = T) - random_agent_UP5_UPnotchosen_sum) /
                (rational_agent_UP5_UPnotchosen_sum - random_agent_UP5_UPnotchosen_sum) * 100
    
    
    # relative number of optimal action sequences selected 
    optimalUP1_2      <- subset(df_SAT,optimal_seq_exe == T & UP_distance=='1'| 
                                  optimal_but_transfail == T & UP_distance=='1'|
                                  optimal_seq_exe == T & UP_distance=='2'| 
                                  optimal_but_transfail == T & UP_distance=='2')
    
    optimalUP3_4      <- subset(df_SAT,optimal_seq_exe == T & UP_distance=='3'| 
                                  optimal_but_transfail == T & UP_distance=='3'|
                                  optimal_seq_exe == T & UP_distance=='4'| 
                                  optimal_but_transfail == T & UP_distance=='4')
    
    optimalUP5      <- subset(df_SAT,optimal_seq_exe == T & UP_distance=='5'| 
                                optimal_but_transfail == T & UP_distance=='5')
    
    SAT[i,20] = nrow(optimalUP1_2)/
      (nrow(subset(df_SAT, UP_distance==1 |
                     UP_distance==2)))*100
    SAT[i,21] = nrow(optimalUP3_4)/
      (nrow(subset(df_SAT, UP_distance==3 |
                     UP_distance==4)))*100
    SAT[i,22] = nrow(optimalUP5)/
      (nrow(subset(df_SAT, UP_distance==5)))*100
    
    
    ## planning depth ####
    # mean planning depth
    SAT[i,23] = mean(df_SAT$PD_lowprob_pruning,na.rm=T)

    # mean PD UP1 ...5 overall 
    SAT[i,24] = mean(UP1$PD_lowprob_pruning,na.rm=T)
    SAT[i,25] = mean(UP2$PD_lowprob_pruning,na.rm=T)
    SAT[i,26] = mean(UP3$PD_lowprob_pruning,na.rm=T)
    SAT[i,27] = mean(UP4$PD_lowprob_pruning,na.rm=T)
    SAT[i,28] = mean(UP5$PD_lowprob_pruning,na.rm=T)

    # combined mean for trials where re-planning costs are the same (4 or 2 branches)
    SAT[i,29] = mean(UP1_2$PD_lowprob_pruning,na.rm=T)
    SAT[i,30] = mean(UP3_4$PD_lowprob_pruning,na.rm=T)
    
    # exclusively for those mini-blocks where the uncertain planet was selected
    SAT[i,31] = mean(df_SAT$PD_lowprob_pruning[df_SAT$uncertain_planet_chosen==T],na.rm=T)
    
    SAT[i,32] = mean(UP1_2$PD_lowprob_pruning[UP1_2$uncertain_planet_chosen==T],na.rm=T)
    SAT[i,33] = mean(UP3_4$PD_lowprob_pruning[UP3_4$uncertain_planet_chosen==T],na.rm=T)
    SAT[i,34] = mean(UP5$PD_lowprob_pruning[UP5$uncertain_planet_chosen==T],na.rm=T)
    
    # exclusively for those mini-blocks where the uncertain planet was NOT selected
    SAT[i,35] = mean(df_SAT$PD_lowprob_pruning[df_SAT$uncertain_planet_chosen==F],na.rm=T)
    
    SAT[i,36] = mean(UP1_2$PD_lowprob_pruning[UP1_2$uncertain_planet_chosen==F],na.rm=T)
    SAT[i,37] = mean(UP3_4$PD_lowprob_pruning[UP3_4$uncertain_planet_chosen==F],na.rm=T)
    SAT[i,38] = mean(UP5$PD_lowprob_pruning[UP5$uncertain_planet_chosen==F],na.rm=T)
    
    
    ## Response times (RTs) in milliseconds ####
    # number of excluded trails (RT outliers < 150ms and >99th percentile)
    SAT[i,39]  = nrow(RT1outlier)
    
    # time needed for task in minutes (+ 1 second ITI per trial(144 trials --> 2.4 minutes extra time); optional breaks are not included)
    SAT[i,40] = sum(df_SAT$RT1,df_SAT$RT2,df_SAT$RT3,na.rm=T)/1000/60+2.4 
    
    
    # overall
    # RT1
    SAT[i,41] = mean(df_SAT$RT1,na.rm=T)
    # RT2
    SAT[i,42] = mean(df_SAT$RT2,na.rm=T)
    # RT3
    SAT[i,43] = mean(df_SAT$RT3,na.rm=T) 
    
    # planning time UP1 ...5 overall 
    SAT[i,44] = mean(UP1$RT1)
    SAT[i,45] = mean(UP2$RT1)
    SAT[i,46] = mean(UP3$RT1)
    SAT[i,47] = mean(UP4$RT1)
    SAT[i,48] = mean(UP5$RT1)
    
    # combined mean for trials where re-planning costs are the same (4 or 2 branches)
    SAT[i,49] = mean(UP1_2$RT1)
    SAT[i,50] = mean(UP3_4$RT1)
    
    # planning time when uncertain planet selected
    SAT[i,51] = mean(df_SAT$RT1[df_SAT$uncertain_planet_chosen==T])
    
    SAT[i,52] = mean(UP1$RT1[UP1$uncertain_planet_chosen==T])
    SAT[i,53] = mean(UP2$RT1[UP2$uncertain_planet_chosen==T])
    SAT[i,54] = mean(UP3$RT1[UP3$uncertain_planet_chosen==T])
    SAT[i,55] = mean(UP4$RT1[UP4$uncertain_planet_chosen==T])
    SAT[i,56] = mean(UP5$RT1[UP5$uncertain_planet_chosen==T])
    
    SAT[i,57] = mean(UP1_2$RT1[UP1_2$uncertain_planet_chosen==T])
    SAT[i,58] = mean(UP3_4$RT1[UP3_4$uncertain_planet_chosen==T])
    
    # planning time when uncertain planet NOT selected
    SAT[i,59] = mean(df_SAT$RT1[df_SAT$uncertain_planet_chosen==F])
    
    SAT[i,60] = mean(UP1$RT1[UP1$uncertain_planet_chosen==F])
    SAT[i,61] = mean(UP2$RT1[UP2$uncertain_planet_chosen==F])
    SAT[i,62] = mean(UP3$RT1[UP3$uncertain_planet_chosen==F])
    SAT[i,63] = mean(UP4$RT1[UP4$uncertain_planet_chosen==F])
    SAT[i,64] = mean(UP5$RT1[UP5$uncertain_planet_chosen==F])
    
    SAT[i,65] = mean(UP1_2$RT1[UP1_2$uncertain_planet_chosen==F])
    SAT[i,66] = mean(UP3_4$RT1[UP3_4$uncertain_planet_chosen==F])
    
    # RT (re-planning/no re-planning) after probabilistic or deterministic transition 
    SAT[i,67] = mean(UP1_noreplan$RT2) 
    SAT[i,68] = nrow(UP1_noreplan) 
    
    SAT[i,69] = mean(UP1_replan$RT2)  
    SAT[i,70] = nrow(UP1_replan) 
    

    SAT[i,71] = mean(UP2_noreplan$RT3[UP2_noreplan$action1==1 & UP2_noreplan$action2==2]) 
    SAT[i,72] = nrow(UP2_noreplan[(UP2_noreplan$action1==1 & UP2_noreplan$action2==2),]) 
    
    SAT[i,73] = mean(UP2_replan$RT3[UP2_replan$action1==1 & UP2_replan$action2==2]) 
    SAT[i,74] = nrow(UP2_replan[(UP2_replan$action1==1 & UP2_replan$action2==2), ]) 
    
    
    SAT[i,75] = mean(UP2_noreplan$RT2[UP2_noreplan$action1==2])
    SAT[i,76] = nrow(UP2_noreplan[(UP2_noreplan$action1==2),])
    
    SAT[i,77] = mean(UP2_replan$RT2[UP2_replan$action1==2])
    SAT[i,78] = nrow(UP2_replan[(UP2_replan$action1==2),])
    
  
    SAT[i,79] = mean(UP3_noreplan$RT3)
    SAT[i,80] = nrow(UP3_noreplan)
    
    SAT[i,81] = mean(UP3_replan$RT3)
    SAT[i,82] = nrow(UP3_replan)
    
    SAT[i,83] = mean(UP4_noreplan$RT3)
    SAT[i,84] = nrow(UP4_noreplan)
    
    SAT[i,85] = mean(UP4_replan$RT3)
    SAT[i,86] = nrow(UP4_replan)
    
    
    SAT[i,87] = mean(UP1$RT2[UP1$uncertain_planet_transsuccess==T])
    SAT[i,88] = nrow(UP1[(UP1$uncertain_planet_transsuccess==T),])
    
    SAT[i,89] = mean(UP2$RT2[UP2$action1==2 & UP2$uncertain_planet_transsuccess==T])
    SAT[i,90] = nrow(UP2[(UP2$action1==2 & UP2$uncertain_planet_transsuccess==T),])
    
    SAT[i,91] = mean(UP1$RT2[UP2$action1==2])
    SAT[i,92] = nrow(UP1[(UP2$action1==2),])
    
    
    SAT[i,93] = mean(UP3$RT3[UP3$uncertain_planet_transsuccess==T])
    SAT[i,94] = nrow(UP3[(UP3$uncertain_planet_transsuccess==T),])
    
    SAT[i,95] = mean(UP4$RT3[UP4$uncertain_planet_transsuccess==T & UP4$action1==2 & UP4$action2==2])
    SAT[i,96] = nrow(UP4[(UP4$uncertain_planet_transsuccess==T & UP4$action1==2 & UP4$action2==2),])
    
    SAT[i,97] = mean(UP2$RT2[UP2$action1==1 & UP2$action2==2])
    SAT[i,98] = nrow(UP2[(UP2$action1==1 & UP2$action2==2),])
    
    # number of mini-blocks 
    SAT[i,99] = nrow(UP1_2)
    SAT[i,100] = nrow(UP3_4)
    SAT[i,101] = nrow(UP5)
    
    SAT[i,102] = nrow(subset(UP1_2,uncertain_planet_chosen==T))
    SAT[i,103] = nrow(subset(UP3_4,uncertain_planet_chosen==T))
    SAT[i,104] = nrow(subset(UP5,uncertain_planet_chosen==T))
    
    SAT[i,105] = nrow(subset(UP1_2,uncertain_planet_chosen==F))
    SAT[i,106] = nrow(subset(UP3_4,uncertain_planet_chosen==F))
    SAT[i,107] = nrow(subset(UP5,uncertain_planet_chosen==F))
    
    
    SAT[i,108] = mean(UP1_transfail$RT2)
    SAT[i,109] = nrow(UP1_transfail)
    
    SAT[i,110] = mean(UP2_transfail$RT2)
    SAT[i,111] = nrow(UP2_transfail)
 

    # report participant-IDs with problems reading the log file
  }, error = function(e) {
    message("a problem occured - please check subject folder: ", folders[i])
    message("Fehler bei Teilnehmer: ", subj)
    message("Fehler: ", e$message)
  })
  setwd(datadir)
}

## construct data frame with summarized participant data ####
# name columns 
dimnames(SAT) = list(1:nid,c(
  "participant_ID",
  "responses_total",

  # absolute amount of points gained in total
  "gain_total",
  
  # relative amount of points (%)
  # calculate new gain scale between optimal and random
  "rel_gain_total",
  
  # compute relative performance per mini-block type
  "rel_gain_UP1",
  "rel_gain_UP2",
  "rel_gain_UP3",
  "rel_gain_UP4",
  "rel_gain_UP5",
  
  # relative performance for mini-block types with equal amount of re-planning costs
  "UP1_2_rel_gain",
  "UP3_4_rel_gain",
  
  
  # relative performance overall when UP selected
  # overall
  "rel_gain_UPchosen",
  
  # for mini-blocks with equal amount of re-planning costs
  "rel_gain_UP1_2_UPchosen",
  "rel_gain_UP3_4_UPchosen",
  "rel_gain_UP5_UPchosen",
  
  # relative performance overall when UP NOT selected
  # overall
  "rel_gain_UPnotchosen",
  
  # for mini-blocks with equal amount of re-planning costs
  "rel_gain_UP1_2_UPnotchosen",
  "rel_gain_UP3_4_UPnotchosen",
  "rel_gain_UP5_UPnotchosen",
  
  
  # relative nb of optimal action sequences selected   
  "rel_optimal_seq_UP1_2",
  "rel_optimal_seq_UP3_4",
  "rel_optimal_seq_UP5",
  
  # mean planning depth (PD)
  "PD_overall",
  
  # mean PD UP1 ...5 overall 
  "PD_UP1",
  "PD_UP2",
  "PD_UP3",
  "PD_UP4",
  "PD_UP5",
  
  # combined mean for trials where re-planning costs are the same (4 or 2 branches)
  "PD_UP1_2",
  "PD_UP3_4",
  
  # PD exclusively for those mini-blocks where the uncertain planet was selected
  "PD_UPchosen",
  
  "PD_UP1_2_UPchosen",
  "PD_UP3_4_UPchosen",
  "PD_UP5_UPchosen",
  
  # PD exclusively for those mini-blocks where the uncertain planet was NOT selected
  "PD_UPnotchosen",
  
  "PD_UP1_2_UPnotchosen",
  "PD_UP3_4_UPnotchosen",
  "PD_UP5_UPnotchosen",
  
  # Response times (RTs) in milliseconds
  # number of excluded trails (RT outliers < 150ms and >99th percentile)
  "RT_outlier_150ms_99percentile",
  # time needed for task in minutes (+ 1 second ITI per trial(144 trials --> 2.4 minutes extra time); optional breaks are not included)
  "time4task_min",
  
  "mean_RT1_total",
  "mean_RT2_total",
  "mean_RT3_total",
  
  # planning time UP1 ...5 overall 
  "RT1_UP1",
  "RT1_UP2",
  "RT1_UP3",
  "RT1_UP4",
  "RT1_UP5",
  
  # combined mean for trials where re-planning costs are the same (4 or 2 branches)
  "UP1_2_RT1",
  "UP3_4_RT1",
  
  # planning time when uncertain planet selected
  "RT1_UPchosen",
  
  "RT1_UP1_UPchosen",
  "RT1_UP2_UPchosen",
  "RT1_UP3_UPchosen",
  "RT1_UP4_UPchosen",
  "RT1_UP5_UPchosen",
  
  "RT1_UP1_2UPchosen",
  "RT1_UP3_4UPchosen",
  
  # planning time when uncertain planet NOT selected
  "RT1_UPnotchosen",
  
  "RT1_UP1_UPnotchosen",
  "RT1_UP2_UPnotchosen",
  "RT1_UP3_UPnotchosen",
  "RT1_UP4_UPnotchosen",
  "RT1_UP5_UPnotchosen",
  
  "UP1_2_RT1_UPnotchosen",
  "UP3_4_RT1_UPnotchosen",
  
  
  
  # RT (re-planning/no re-planning) after probabilistic or deterministic transition 
  "UP1_RTnoreplan",
  "n_UP1_noreplan",
  
  "UP1_RTreplan",
  "n_UP1_replan",
  
  
  "UP2_RTnoreplan_2actions",
  "n_UP2_noreplan_2actions",
  
  "UP2_RTreplan_2actions",
  "n_UP2_replan_2actions",
  
  
  "UP2_RTnoreplan_1action",
  "n_UP2_noreplan_1action",
  
  "UP2_RTreplan_1action",
  "n_UP2_replan_1action",
  
  
  
  "UP3_RTnoreplan",
  "n_UP3_noreplan",
  
  "UP3_RTreplan",
  "n_UP3_replan",
  
  "UP4_RTnoreplan",
  "n_UP4_noreplan",
  
  "UP4_RTreplan",
  "n_UP4_replan",
  
  
  "UP1_RTtranssuccess",
  "n_UP1_transsuccess",
  
  "UP2_RTtranssuccess",
  "n_UP2_transsuccess",
  
  "UP1_RTdeterm_1action",
  "n_UP1_RTdeterm_1action",
  
  
  "UP3_RTtranssuccess",
  "n_UP3_transsuccess",
  
  "UP4_RTtranssuccess",
  "n_UP4_transsuccess",
  
  "UP2_RTdeterm_2actions",
  "n_UP2_RTdeterm_2actions",
  
  
  
  # number of mini-blocks 
  "UP1_2_n_trials",
  "UP3_4_n_trials",
  "UP5_n_trials",
  
  "N_UP1_2_UPchosen",
  "N_UP3_4_UPchosen",
  "N_UP5_UPchosen",
  
  "N_UP1_2_UPnotchosen",
  "N_UP3_4_UPnotchosen",
  "N_UP5_UPnotchosen",
  
  "UP1_RTtransfail",
  "n_UP1_transfail",
  
  "UP2_RTtransfail",
  "n_UP2_transfail"

))

# create data frame
B3_SAT <- data.frame(SAT)
B3_SAT[ is.na(B3_SAT) ] <- NA

# converting all columns to numeric values
B3_SAT[ ,c(1:ncol(B3_SAT))]         <- lapply(B3_SAT[ ,c(1:ncol(B3_SAT))], as.numeric)

# Creating the 'balancing' column based on 'participant_ID'
B3_SAT$balancing <- ifelse(B3_SAT$participant_ID %% 2 == 0, 1, 2)
# Converting some columns to a factor type
B3_SAT$balancing <- as.factor(B3_SAT$balancing)
 
# save data #####
savedir = ("")
path_C <- paste0(savedir, "/B3_SAT_144trials_public",".csv", sep="")
write.csv(B3_SAT, file=path_C, row.names=F)

