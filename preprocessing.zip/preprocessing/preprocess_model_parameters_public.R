# by Sophia-Helen Sass (2025)
# load and preprocess inferred parameters (except planning depth) from behavioral models
# planning depth is preprocessed in "SAT_UP_data_preprocessing_144_trials_public.R"

# prepare workspace and data ####
#clear workspace
rm(list = ls())

# set directory 
setwd('')
participant_ID <- read.csv("participant_ID_pilot_2_pilot3.csv") # ID list from inference
participant_ID$subject <- seq(1:74)

# exhaustive full-breadth planning model ####
# here called "rational" model
# read in parameters from inference
params <- read.csv("pars_post_samples_fit-rational_pilot3.csv")
params$X <- NULL

# put parameters in order (THETA, BETA)
row_len <- length(params$parameter[params$parameter=="$\\theta$"])
params_ordered <- data.frame(subject=rep(NA,row_len),
                             theta=rep(NA,row_len),
                             beta=rep(NA,row_len))

params_ordered$subject <- params$subject[params$parameter=="$\\theta$"]
params_ordered$theta <- params$value[params$parameter=="$\\theta$"]
params_ordered$beta <- params$value[params$parameter=="$\\beta$"]

# build common data frame with one row of means per subject
row_len <- length(table(params_ordered$subject))

mean_params_ordered <- data.frame(subject=rep(NA,row_len),
                                  rational_theta=rep(NA,row_len),
                                  rational_beta=rep(NA,row_len)
                                  )
                                  
for (i in seq(1:row_len)) {
  mean_params_ordered$subject[i]        <- params_ordered$subject[params_ordered$subject==i][1]   
  mean_params_ordered$rational_theta[i] <- mean(params_ordered$theta[params_ordered$subject==i])
  mean_params_ordered$rational_beta[i]  <- mean(params_ordered$beta[params_ordered$subject==i])
  }

params_rational<- mean_params_ordered



# low-probability pruning model ####
# read in parameters from inference
params <- read.csv("pars_post_samples_fit-lowprob_pruning_pilot3.csv")
params$X <- NULL

# put parameters in order (THETA, BETA)
row_len <- length(params$parameter[params$parameter=="$\\theta$"])
params_ordered <- data.frame(subject=rep(NA,row_len),
                             theta=rep(NA,row_len),
                             beta=rep(NA,row_len))

params_ordered$subject <- params$subject[params$parameter=="$\\theta$"]
params_ordered$theta <- params$value[params$parameter=="$\\theta$"]
params_ordered$beta <- params$value[params$parameter=="$\\beta$"]

# build common data frame with one row of means per subject
row_len <- length(table(params_ordered$subject))
mean_params_ordered <- data.frame(subject=rep(NA,row_len),
                                  lowprob_prun_theta=rep(NA,row_len),
                                  lowprob_prun_beta=rep(NA,row_len))

for (i in seq(1:row_len)) {
  
  mean_params_ordered$subject[i]       <- params_ordered$subject[params_ordered$subject==i][1]   
  mean_params_ordered$lowprob_prun_theta[i] <- mean(params_ordered$theta[params_ordered$subject==i])
  mean_params_ordered$lowprob_prun_beta[i]  <- mean(params_ordered$beta[params_ordered$subject==i])
}

params_lowprob_pruning<- mean_params_ordered




# discounted low-probability pruning model ####
# read in parameters from inference
params <- read.csv("pars_post_samples_fit-discounting_lowprob_pruning_pilot3.csv")
params$X <- NULL

# put parameters in order (THETA, BETA, KAPPA)
row_len <- length(params$parameter[params$parameter=="$\\theta$"])
params_ordered <- data.frame(subject=rep(NA,row_len),
                             theta=rep(NA,row_len),
                             beta=rep(NA,row_len),
                             kappa=rep(NA,row_len))

params_ordered$subject <- params$subject[params$parameter=="$\\theta$"]
params_ordered$theta <- params$value[params$parameter=="$\\theta$"]
params_ordered$beta <- params$value[params$parameter=="$\\beta$"]
params_ordered$kappa <- params$value[params$parameter=="$k$"]

# build common data frame with one row of means per subject
row_len <- length(table(params_ordered$subject))
mean_params_ordered <- data.frame(subject=rep(NA,row_len),
                                  disc_lowprob_pruning_theta=rep(NA,row_len),
                                  disc_lowprob_pruning_beta=rep(NA,row_len),
                                  disc_lowprob_pruning_kappa=rep(NA,row_len))

for (i in seq(1:row_len)) {
  
  mean_params_ordered$subject[i]       <- params_ordered$subject[params_ordered$subject==i][1]   
  mean_params_ordered$disc_lowprob_pruning_theta[i] <- mean(params_ordered$theta[params_ordered$subject==i])
  mean_params_ordered$disc_lowprob_pruning_beta[i]  <- mean(params_ordered$beta[params_ordered$subject==i])
  mean_params_ordered$disc_lowprob_pruning_kappa[i]  <- mean(params_ordered$kappa[params_ordered$subject==i])
  
  }

params_disc_lowprob_pruning<- mean_params_ordered




# merge the individual data frames ####
all_params <- merge(params_rational,params_lowprob_pruning, by = 'subject')
all_params <- merge(all_params,params_disc_lowprob_pruning, by = 'subject')
all_params <- merge(all_params, participant_ID, by = "subject")

# dave data as csv ####
savedir = ("")
path_C <- paste0(savedir, "/SAT_UP_params_public", ".csv", sep="")
write.csv(all_params, file=path_C, row.names=F)
